package horsreservationclient;

import ejb.session.stateless.GuestSessionBeanRemote;
import ejb.session.stateless.OnlineReservationSessionBeanRemote;
import ejb.session.stateless.ReservationControllerSessionBeanRemote;
import ejb.session.stateless.RoomManagementSessionBeanRemote;
import entity.Employee;
import entity.Guest;
import entity.OnlineReservation;
import entity.Reservation;
import entity.ReservationDetail;
import entity.Room;
import entity.RoomType;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import java.util.Scanner;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import util.enumeration.StatusEnum;
import util.exception.GuestEmailExistException;
import util.exception.InputDataValidationException;
import util.exception.InvalidLoginCredentialException;
import util.exception.ReservationNotFoundException;
import util.exception.UnknownPersistenceException;

public class MainApp {
	
	private final ValidatorFactory validatorFactory;
	private final Validator validator;

	private GuestSessionBeanRemote guestSessionBeanRemote;
	private RoomManagementSessionBeanRemote roomManagementSessionBeanRemote;
	private ReservationControllerSessionBeanRemote reservationControllerSessionBeanRemote;
	private OnlineReservationSessionBeanRemote onlineReservationSessionBeanRemote;
	private Guest currentGuest;

	public MainApp() {
		validatorFactory = Validation.buildDefaultValidatorFactory();
		validator = validatorFactory.getValidator();
	}

	public MainApp(GuestSessionBeanRemote guestSessionBeanRemote, RoomManagementSessionBeanRemote roomManagementSessionBeanRemote, ReservationControllerSessionBeanRemote reservationControllerSessionBeanRemote, OnlineReservationSessionBeanRemote onlineReservationSessionBeanRemote) {
		this();
		this.guestSessionBeanRemote = guestSessionBeanRemote;
		this.roomManagementSessionBeanRemote = roomManagementSessionBeanRemote;
		this.reservationControllerSessionBeanRemote = reservationControllerSessionBeanRemote;
		this.onlineReservationSessionBeanRemote = onlineReservationSessionBeanRemote;
	}

	public void runApp() {
		Scanner scanner = new Scanner(System.in);
		Integer response = 0;

		while (true) {
			System.out.println("*** Welcome to HoRS Reservation Client ***\n");
			System.out.println("1: Register");
			System.out.println("2: Login");
			System.out.println("3: Search Hotel Room");
			System.out.println("4: Exit\n");
			response = 0;

			while (response < 1 || response > 3) {
				System.out.print("> ");

				response = scanner.nextInt();

				if (response == 1) {
					doCreateNewGuest();

				} else if (response == 2) {

					try {
						doLogin();
						menuMain();

					} catch (InvalidLoginCredentialException ex) {
						System.out.println("Invalid login credential: " + ex.getMessage() + "\n");
					}

				} else if (response == 3) {

					doVisitorSearchHotelRoom();

				} else if (response == 4) {
					break;

				} else {
					System.out.println("Invalid option, please try again!\n");
				}
			}

			if (response == 4) {
				break;
			}
		}
	}

	private void doCreateNewGuest() {
		Scanner scanner = new Scanner(System.in);
		Guest newGuestEntity = new Guest();

		System.out.println("*** HoRS Reservation Client  :: Create New Guest ***\n");
		System.out.print("Enter Email> ");
		newGuestEntity.setEmail(scanner.nextLine().trim());
		System.out.print("Enter First Name> ");
		newGuestEntity.setFirstName(scanner.nextLine().trim());
		System.out.print("Enter Last Name> ");
		newGuestEntity.setLastName(scanner.nextLine().trim());
		System.out.print("Enter Password> ");
		newGuestEntity.setPassword(scanner.nextLine().trim());
		
		Set<ConstraintViolation<Guest>> constraintViolations = validator.validate(newGuestEntity);

		if (constraintViolations.isEmpty()) {
			try {
				Long newGuestId = guestSessionBeanRemote.registerNewGuest(newGuestEntity);
				System.out.println("New guest created successfully!: " + newGuestId + "\n");
			} catch (GuestEmailExistException ex) {
				System.out.println("An error has occurred while creating the new guest!: The email already exist\n");
			} catch (UnknownPersistenceException ex) {
				System.out.println("An unknown error has occurred while creating the new guest!: " + ex.getMessage() + "\n");
			} catch(InputDataValidationException ex){
				System.out.println(ex);
			}
		} else {
			showInputDataValidationErrorsForGuest(constraintViolations);
		}
	}

	private void doLogin() throws InvalidLoginCredentialException {
		Scanner scanner = new Scanner(System.in);
		String email = "";
		String password = "";

		System.out.println("*** HoRS Reservation Client :: Login ***\n");
		System.out.print("Enter email> ");
		email = scanner.nextLine().trim();
		System.out.print("Enter password> ");
		password = scanner.nextLine().trim();

		if (email.length() > 0 && password.length() > 0) {
			currentGuest = guestSessionBeanRemote.guestLogin(email, password);
		} else {
			throw new InvalidLoginCredentialException("Missing login credential!");
		}
	}

	public void menuMain() {

		Scanner scanner = new Scanner(System.in);
		Integer response = 0;

		while (true) {
			System.out.println("*** HoRS Reservation Client ***\n");
			System.out.println("You are login as " + currentGuest.getFirstName() + " " + currentGuest.getLastName());

			System.out.println("1: Search Hotel Room");
			System.out.println("2: View My Reservation Details");
			System.out.println("3: View All My Reservations");
			System.out.println("4: Logout\n");
			response = 0;

			while (response < 1 || response > 4) {
				System.out.print("> ");
				response = scanner.nextInt();

				if (response == 1) {
					doGuestSearchHotelRoom();
				} else if (response == 2) {
					doViewMyReservationDetails();
				} else if (response == 3) {
					doViewAllMyReservations();
				} else if (response == 4) {
					break;
				} else {
					System.out.println("Invalid option, please try again!\n");
				}
			}

			if (response == 4) {
				break;
			}

		}
	}

	public void doGuestSearchHotelRoom() {
		try {
			Scanner scanner = new Scanner(System.in);
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

			System.out.println("*** Hotel Reservation System (HoRS) :: Front Office :: Walk-in Search Room ***\n");

			System.out.print("Enter check-in date (yyyy-MM-dd)> ");
			Date checkInDate = simpleDateFormat.parse(scanner.nextLine().trim());
			System.out.print("Enter check-out date (yyyy-MM-dd)> ");
			Date checkOutDate = simpleDateFormat.parse(scanner.nextLine().trim());

			List<RoomType> roomTypes = roomManagementSessionBeanRemote.retrieveAllRoomTypes();
			boolean hasAvailableRooms = false;
			int index = 1;

			System.out.println("\nAvailable Room Types:");

			for (RoomType roomType : roomTypes) {
				if (roomType.getRoomRates().isEmpty()) {
					continue; // Skip room types without associated room rates
				}
				
				int totalRooms = roomType.getRooms().size();
				int availableRooms = totalRooms;

				//	 Deduct rooms that are not in an inactive status (disabled or unavailable)
				for (Room room : roomType.getRooms()) {
					if (room.getStatus().equals(StatusEnum.DISABLED)) {
						availableRooms--;
					}
				}

				// Deduct rooms based on overlapping reservations
				List<ReservationDetail> reservations = reservationControllerSessionBeanRemote.retrieveReservationDetailsByRoomTypeAndDate(roomType, checkInDate, checkOutDate);
				for (ReservationDetail reservationDetail : reservations) {
					availableRooms -= reservationDetail.getNumOfRooms();
				}

				if (availableRooms > 0) {
					System.out.println(index + ". " + roomType.getName() + " Room Type: " + availableRooms + " rooms available.");
					index++;
					hasAvailableRooms = true;
				} else {
					System.out.println(index + ". " + roomType.getName() + " Room Type has no rooms available.");
				}
			}

			// Prompt for reservation if rooms are available
			if (hasAvailableRooms) {
				System.out.print("\nWould you like to make a reservation? (y/n): ");
				String response = scanner.nextLine().trim();

				if (response.equalsIgnoreCase("y")) {
					handleReservationSelection(scanner, roomTypes, checkInDate, checkOutDate, index);
				} else {
					System.out.println("Reservation canceled.");
				}
			} else {
				System.out.println("No rooms available for the selected dates.");
			}

		} catch (ParseException ex) {
			System.out.println("Invalid Date Input.");
		}

	}

	private void handleReservationSelection(Scanner scanner, List<RoomType> roomTypes, Date checkInDate, Date checkOutDate, int index) {
		Map<RoomType, Integer> roomTypesToReserve = new HashMap<>();

		while (true) {
			int selectedRoomTypeNumber = 0;
			System.out.print("\nEnter the corresponding number of the room type to reserve (or 0 to finish selection): ");
			try{
			selectedRoomTypeNumber = Integer.parseInt(scanner.nextLine().trim());
			} catch(NumberFormatException e){
				System.out.println("Invalid Input. Please enter a valid Number");
				continue;
			}

			// Exit if user selects 0
			if (selectedRoomTypeNumber == 0) {
				break;
			}

			if (selectedRoomTypeNumber >= 1 && selectedRoomTypeNumber < index) {
				RoomType selectedRoomType = roomTypes.get(selectedRoomTypeNumber - 1);

				// Calculate available rooms for the selected room type using the updated logic
				int availableRooms = selectedRoomType.getRooms().size();
				for (Room room : selectedRoomType.getRooms()) {
					if (room.getStatus().equals(StatusEnum.DISABLED)) {
						availableRooms--;
					}
				}

				List<ReservationDetail> reservations = reservationControllerSessionBeanRemote.retrieveReservationDetailsByRoomTypeAndDate(selectedRoomType, checkInDate, checkOutDate);
				for (ReservationDetail reservationDetail : reservations) {
					availableRooms -= reservationDetail.getNumOfRooms();
				}

				System.out.println("Available rooms for " + selectedRoomType.getName() + ": " + availableRooms);
				System.out.print("Enter the number of rooms to reserve for " + selectedRoomType.getName() + "> ");
				int numRoomsToReserve = Integer.parseInt(scanner.nextLine().trim());

				if (numRoomsToReserve <= availableRooms) {
					roomTypesToReserve.put(selectedRoomType, numRoomsToReserve);
					System.out.println(numRoomsToReserve + " rooms added for " + selectedRoomType.getName() + ".");
				} else {
					System.out.println("Not enough rooms available in " + selectedRoomType.getName() + ". Available: " + availableRooms);
				}
			} else {
				System.out.println("Invalid selection. Please enter a valid number.");
			}
		}

		if (!roomTypesToReserve.isEmpty()) {
			Long reservationID = doReserveRoom(checkInDate, checkOutDate, roomTypesToReserve);
			if (reservationID != null) {
				System.out.println("Reservation successful for the selected room types. Your Reservation ID is: " + reservationID);
			} else {
				System.out.println("Reservation process failed.");
			}
		} else {
			System.out.println("No valid room types were selected. Reservation canceled.");
		}
	}

	public Long doReserveRoom(Date checkInDate, Date checkOutDate, Map<RoomType, Integer> numRoomTypesToReserve) {
		try {
			OnlineReservation newOnlineReservation = new OnlineReservation();
			newOnlineReservation.setStartDate(checkInDate);
			newOnlineReservation.setEndDate(checkOutDate);
			newOnlineReservation.setGuest(currentGuest);

			BigDecimal totalAmount = BigDecimal.ZERO;

			// Loop through each RoomType to reserve rooms
			for (Map.Entry<RoomType, Integer> entry : numRoomTypesToReserve.entrySet()) {
				RoomType roomType = entry.getKey();
				int numRoomsToReserve = entry.getValue();

				ReservationDetail reservationDetail = new ReservationDetail();
				reservationDetail.setNumOfRooms(numRoomsToReserve);
				reservationDetail.setRoomType(roomType);
				newOnlineReservation.getReservationDetails().add(reservationDetail);

				BigDecimal amountForRoomType = onlineReservationSessionBeanRemote.calculateAmount(roomType, numRoomsToReserve, checkInDate, checkOutDate);
				totalAmount = totalAmount.add(amountForRoomType);
			}
			
			newOnlineReservation.setReservationFee(totalAmount);
			
			System.out.println("The total reservation fee is: " + totalAmount);
			System.out.print("Do you want to proceed with the reservation? (y/n): ");
			Scanner scanner = new Scanner(System.in);
			String confirmation = scanner.nextLine().trim();

			if (confirmation.equalsIgnoreCase("y")) {
				OnlineReservation persistedReservation = reservationControllerSessionBeanRemote.createNewOnlineReservation(currentGuest.getGuestId(), newOnlineReservation);
				System.out.println("Reservation successful. Reservation ID: " + persistedReservation.getReservationId());
				return persistedReservation.getReservationId();
			} else {
				System.out.println("Reservation canceled by the user.");
				return null;
			}

		} catch (Exception e) {
			System.out.println("Failed to create reservation: " + e.getMessage());
			return null;
		}
	}

	public void doVisitorSearchHotelRoom() {
		try {

			Scanner scanner = new Scanner(System.in);
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

			System.out.println("*** HoRS Reservation Client :: Walk-in Search Room ***\n");

			System.out.print("Enter check-in date (yyyy-MM-dd)> ");
			Date checkInDate = simpleDateFormat.parse(scanner.nextLine().trim());
			System.out.print("Enter check-out date (yyyy-MM-dd)> ");
			Date checkOutDate = simpleDateFormat.parse(scanner.nextLine().trim());

			List<RoomType> roomTypes = roomManagementSessionBeanRemote.retrieveAllRoomTypes();
			boolean hasAvailableRooms = false;
			int index = 1;

			System.out.println("\nAvailable Room Types:");

			// Iterate through all room types to calculate available rooms
			for (RoomType roomType : roomTypes) {
				int totalRooms = roomType.getRooms().size();
				int availableRooms = totalRooms;

				//	 Deduct rooms that are not in an inactive status (disabled or unavailable)
				for (Room room : roomType.getRooms()) {
					if (room.getStatus().equals(StatusEnum.DISABLED)) {
						availableRooms--;
					}
				}

				// Deduct rooms based on overlapping reservations
				List<ReservationDetail> reservations = reservationControllerSessionBeanRemote.retrieveReservationDetailsByRoomTypeAndDate(roomType, checkInDate, checkOutDate);
				for (ReservationDetail reservationDetail : reservations) {
					availableRooms -= reservationDetail.getNumOfRooms();
				}

				if (availableRooms > 0) {
					System.out.println(index + ". " + roomType.getName() + " Room Type: " + availableRooms + " rooms available.");
					index++;
					hasAvailableRooms = true;
				} else {
					System.out.println(index + ". " + roomType.getName() + " Room Type has no rooms available.");
				}
			}

		} catch (ParseException ex) {
			System.out.println("Invalid Date Input.");
		}
	}


	public void doViewMyReservationDetails() {
		Scanner scanner = new Scanner(System.in);
		Long reservationId = null;

		System.out.println("*** HoRS Reservation Client :: View My Reservation Details***\n");
		
		while (reservationId == null) {
			System.out.print("Enter Reservation ID> ");
			String input = scanner.nextLine().trim();

			try {
				reservationId = Long.parseLong(input); // Try to parse input as a Long
			} catch (NumberFormatException e) {
				System.out.println("Invalid input. Please enter a valid numeric Reservation ID.");
			}
		}

		try {
			// Retrieve reservation details (Room Type, quantity etc)
			Reservation reservation = reservationControllerSessionBeanRemote.retrieveReservationById(reservationId);
			List<ReservationDetail> reservationDetails = reservation.getReservationDetails();
			
			System.out.printf("%10s%30s%30s%40s\n", "Reservation ID", "Start Date", "End Date", "Reservation Fee");
			System.out.printf("%10s%35s%35s%25s\n", reservation.getReservationId(), reservation.getStartDate(), reservation.getEndDate(), reservation.getReservationFee());

			System.out.println("Your reservation details are as follows: ");
			
			for (ReservationDetail rd : reservationDetails) {
				System.out.printf("%10s%30s\n", "Room Type", "Number of Rooms");
				System.out.printf("%10s%30s\n",  rd.getRoomType().getName(), rd.getNumOfRooms());
			}

			
		} catch (ReservationNotFoundException ex) {
			System.out.println(ex.getMessage());
		}
	}

	public void doViewAllMyReservations() {
		Scanner scanner = new Scanner(System.in);		
		SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, yyyy-MM-dd");

		System.out.println("*** HoRS Reservation Client :: View All My Reservations ***\n");

		Long guestId = currentGuest.getGuestId();
		List<Reservation> reservations = reservationControllerSessionBeanRemote.retrieveOnlineReservationsByGuestId(guestId);

		for (Reservation r : reservations) {
			System.out.printf("%10s%30s%30s%40s\n", "Reservation ID", "Start Date", "End Date", "Reservation Fee");
			System.out.printf("%10s%35s%35s%25s\n", r.getReservationId(), dateFormat.format(r.getStartDate()), dateFormat.format(r.getEndDate()), r.getReservationFee());
	
		}

		System.out.print("Press any key to continue...> ");
		scanner.nextLine();
	}
	
	private void showInputDataValidationErrorsForGuest(Set<ConstraintViolation<Guest>> constraintViolations) {
		System.out.println("\nInput data validation error!:");

		for (ConstraintViolation constraintViolation : constraintViolations) {
			System.out.println("\t" + constraintViolation.getPropertyPath() + " - " + constraintViolation.getInvalidValue() + constraintViolation.getMessage());
		}

		System.out.println("\nPlease try again......\n");
	}

}