package horsreservationclient;

import ejb.session.stateless.GuestSessionBeanRemote;
import ejb.session.stateless.OnlineReservationSessionBeanRemote;
import ejb.session.stateless.ReservationControllerSessionBeanRemote;
import ejb.session.stateless.RoomManagementSessionBeanRemote;
import javax.ejb.EJB;

public class Main {
	
	@EJB
	private static RoomManagementSessionBeanRemote roomManagementSessionBeanRemote;
	
	@EJB
	private static ReservationControllerSessionBeanRemote reservationControllerSessionBeanRemote;

	@EJB
	private static GuestSessionBeanRemote guestSessionBeanRemote;
	
	@EJB
	private static OnlineReservationSessionBeanRemote onlineReservationSessionBeanRemote;

	public static void main(String[] args) {
		MainApp mainApp = new MainApp(guestSessionBeanRemote, roomManagementSessionBeanRemote, reservationControllerSessionBeanRemote, onlineReservationSessionBeanRemote);
		mainApp.runApp();
	}

}
