package horsmanagementclient;

import ejb.session.stateless.EmployeeSessionBeanRemote;
import ejb.session.stateless.PartnerEmployeeSessionBeanRemote;
import entity.Employee;
import entity.PartnerEmployee;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import util.enumeration.EmployeeRoleEnum;
import util.enumeration.PartnerEmployeeRoleEnum;
import util.exception.EmployeeUsernameExistException;
import util.exception.InputDataValidationException;
import util.exception.UnknownPersistenceException;

public class SystemAdministrationModule {
	
	private final ValidatorFactory validatorFactory;
	private final Validator validator;

	private EmployeeSessionBeanRemote employeeSessionBeanRemote;
	private PartnerEmployeeSessionBeanRemote partnerEmployeeSessionBeanRemote;

	private Employee currentEmployee;
	

	public SystemAdministrationModule() {
		validatorFactory = Validation.buildDefaultValidatorFactory();
		validator = validatorFactory.getValidator();
	}

	public SystemAdministrationModule(EmployeeSessionBeanRemote employeeSessionBeanRemote, PartnerEmployeeSessionBeanRemote partnerEmployeeSessionBeanRemote, Employee currentEmployee) {
		this();
		this.employeeSessionBeanRemote = employeeSessionBeanRemote;
		this.partnerEmployeeSessionBeanRemote = partnerEmployeeSessionBeanRemote;
		this.currentEmployee = currentEmployee;
	}

	public void menuMain() {

		Scanner scanner = new Scanner(System.in);
		Integer response = 0;

		while (true) {
			System.out.println("*** Hotel Reservation System (HoRS) :: System Administration ***\n");
			System.out.println("You are login as " + currentEmployee.getFirstName() + " " + currentEmployee.getLastName() + " with " + currentEmployee.getEmployeeRoleEnum().toString() + " rights\n");
			System.out.println("1: Create New Employee");
			System.out.println("2: View All Employees");
			System.out.println("3: Create New Partner");
			System.out.println("4: View All Partners");
			System.out.println("5: Logout\n");
			response = 0;

			while (response < 1 || response > 5) {
				System.out.print("> ");

				String input = scanner.nextLine().trim();
				try {
					response =Integer.parseInt(input);
					
					if (response == 1) {
						doCreateNewEmployee();
					} else if (response == 2) {
						doViewAllEmployees();
					} else if (response == 3) {
						doCreateNewPartner();
					} else if (response == 4) {
						doViewAllPartners();
					} else if (response == 5) {			
						break;
					} else {
						System.out.println("Invalid option, please try again!\n");
					}
				} catch(NumberFormatException ex) {
					System.out.println("Invalid input. Please enter a valid number.\n");
				}
				
			}

			if (response == 5) {
				break;
			}
		}
	}
	
	public void doCreateNewEmployee() {
		Scanner scanner = new Scanner(System.in);
		Employee newEmployee = new Employee();

		System.out.println("*** Hotel Reservation System (HoRS) :: System Administration :: Create New Employee ***\n");
		System.out.print("Enter First Name> ");
		newEmployee.setFirstName(scanner.nextLine().trim());
		System.out.print("Enter Last Name> ");
		newEmployee.setLastName(scanner.nextLine().trim());

		while (true) {
			System.out.print("Select Access Right (1: System Administrator, 2: Operation Manager, 3: Sales Manager, 4: Guest Relation Officer)> ");
			Integer accessRightInt = scanner.nextInt();

			if (accessRightInt >= 1 && accessRightInt <= 4) {
				newEmployee.setEmployeeRoleEnum(EmployeeRoleEnum.values()[accessRightInt - 1]);
				break;
			} else {
				System.out.println("Invalid option, please try again!\n");
			}
		}

		scanner.nextLine();
		System.out.print("Enter Username> ");
		newEmployee.setUsername(scanner.nextLine().trim());
		System.out.print("Enter Password> ");
		newEmployee.setPassword(scanner.nextLine().trim());
		
		Set<ConstraintViolation<Employee>> constraintViolations = validator.validate(newEmployee);

		if (constraintViolations.isEmpty()) {

			try {
				Long newEmployeeId = employeeSessionBeanRemote.createNewEmployee(newEmployee);
				System.out.println("New employee created successfully!: " + newEmployeeId + "\n");
			} catch (EmployeeUsernameExistException ex) {
				System.out.println("An error has occurred while creating the new employee!: The user name already exist\n");
			} catch (UnknownPersistenceException ex) {
				System.out.println("An unknown error has occurred while creating the new employee!: " + ex.getMessage() + "\n");
			} catch(InputDataValidationException ex){
				System.out.println(ex);
			}
		} else {
			showInputDataValidationErrorsForEmployee(constraintViolations);
		}
	}
	
	public void doViewAllEmployees() {
		Scanner scanner = new Scanner(System.in);

		System.out.println("*** Hotel Reservation System (HoRS) :: System Administration :: View All Employees ***\n");

		List<Employee> employees = employeeSessionBeanRemote.retrieveAllEmployees();
		System.out.printf("%8s%20s%20s%25s%20s%20s\n", "Employee ID", "First Name", "Last Name", "Access Right", "Username", "Password");

		for (Employee employee : employees) {
			System.out.printf("%8s%20s%20s%32s%16s%20s\n", employee.getEmployeeId().toString(), employee.getFirstName(), employee.getLastName(), employee.getEmployeeRoleEnum().toString(), employee.getUsername(), employee.getPassword());
		}

		System.out.print("Press any key to continue...> ");
		scanner.nextLine();
	}
	
	public void doCreateNewPartner() {
		Scanner scanner = new Scanner(System.in);
		PartnerEmployee newPartnerEmployee = new PartnerEmployee();

		System.out.println("*** Hotel Reservation System (HoRS) :: System Administration :: Create New Partner ***\n");
		System.out.print("Enter First Name> ");
		newPartnerEmployee.setFirstName(scanner.nextLine().trim());
		System.out.print("Enter Last Name> ");
		newPartnerEmployee.setLastName(scanner.nextLine().trim());
		System.out.print("Enter Username> ");
		newPartnerEmployee.setUsername(scanner.nextLine().trim());
		System.out.print("Enter Password> ");
		newPartnerEmployee.setPassword(scanner.nextLine().trim());
		newPartnerEmployee.setPartnerEmployeeRoleEnum(PartnerEmployeeRoleEnum.PARTNERRESERVATIONMANAGER);
		
		Set<ConstraintViolation<PartnerEmployee>> constraintViolations = validator.validate(newPartnerEmployee);
		if (constraintViolations.isEmpty()) {
			try {
				Long newPartnerEmployeeId = partnerEmployeeSessionBeanRemote.createNewPartnerEmployee(newPartnerEmployee);
				System.out.println("New partner created successfully!: " + newPartnerEmployeeId + "\n");
			} catch (EmployeeUsernameExistException ex) {
				System.out.println("An error has occurred while creating the new partner!: The user name already exist\n");
			} catch (UnknownPersistenceException ex) {
				System.out.println("An unknown error has occurred while creating the new partner!: " + ex.getMessage() + "\n");
			}catch(InputDataValidationException ex){
				System.out.println(ex);
			}
		} else {
			showInputDataValidationErrorsForPartnerEmployee(constraintViolations);
		}
	}
	
	public void doViewAllPartners() {
		Scanner scanner = new Scanner(System.in);

		System.out.println("*** Hotel Reservation System (HoRS) :: System Administration :: View All Partners ***\n");

		List<PartnerEmployee> partnerEmployees = partnerEmployeeSessionBeanRemote.retrieveAllPartners();
		System.out.printf("%8s%20s%20s%25s%20s%20s\n", "Employee ID", "First Name", "Last Name", "Access Right", "Username", "Password");

		for (PartnerEmployee partnerEmployee : partnerEmployees) {
			System.out.printf("%8s%20s%20s%32s%16s%20s\n", partnerEmployee.getPartnerEmployeeId().toString(), partnerEmployee.getFirstName(), partnerEmployee.getLastName(), partnerEmployee.getPartnerEmployeeRoleEnum().toString(), partnerEmployee.getUsername(), partnerEmployee.getPassword());
		}

		System.out.print("Press any key to continue...> ");
		scanner.nextLine();
	}
	
	private void showInputDataValidationErrorsForEmployee(Set<ConstraintViolation<Employee>> constraintViolations) {
		System.out.println("\nInput data validation error!:");

		for (ConstraintViolation constraintViolation : constraintViolations) {
			System.out.println("\t" + constraintViolation.getPropertyPath() + " - " + constraintViolation.getInvalidValue() + constraintViolation.getMessage());
		}

		System.out.println("\nPlease try again......\n");
	}
	
	private void showInputDataValidationErrorsForPartnerEmployee(Set<ConstraintViolation<PartnerEmployee>> constraintViolations) {
		System.out.println("\nInput data validation error!:");

		for (ConstraintViolation constraintViolation : constraintViolations) {
			System.out.println("\t" + constraintViolation.getPropertyPath() + " - " + constraintViolation.getInvalidValue() + constraintViolation.getMessage());
		}

		System.out.println("\nPlease try again......\n");
	}
}
