package horsmanagementclient;

import ejb.session.stateless.ReservationControllerSessionBeanRemote;
import ejb.session.stateless.RoomAllocationSessionBeanRemote;
import ejb.session.stateless.RoomManagementSessionBeanRemote;
import entity.AllocationReport;
import entity.Employee;
import entity.PartnerEmployee;
import entity.ReservationDetail;
import entity.Room;
import entity.RoomRate;
import entity.RoomType;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import java.util.Scanner;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import util.enumeration.AllocationStatusEnum;
import util.enumeration.EmployeeRoleEnum;
import util.enumeration.RateTypeEnum;
import util.enumeration.StatusEnum;
import util.exception.AllocationReportNotFoundException;
import util.exception.CreateNewRoomException;

import util.exception.DeleteRoomException;
import util.exception.DeleteRoomRateException;
import util.exception.DeleteRoomTypeException;
import util.exception.DuplicateRoomException;
import util.exception.DuplicateRoomTypeException;
import util.exception.RoomNotFoundException;
import util.exception.RoomRateNotFoundException;
import util.exception.RoomTypeNotFoundException;
import util.exception.UnknownPersistenceException;
import util.exception.UpdateRoomException;
import util.exception.UpdateRoomRateException;
import util.exception.UpdateRoomTypeException;

public class HotelOperationModule {
	
	private final ValidatorFactory validatorFactory;
	private final Validator validator;

	private RoomManagementSessionBeanRemote roomManagementSessionBeanRemote;
	private Employee currentEmployee;
	private ReservationControllerSessionBeanRemote reservationControllerSessionBeanRemote;
	private RoomAllocationSessionBeanRemote roomAllocationSessionBeanRemote;

	public HotelOperationModule() {
		validatorFactory = Validation.buildDefaultValidatorFactory();
		validator = validatorFactory.getValidator();
	}

	public HotelOperationModule(RoomManagementSessionBeanRemote roomManagementSessionBeanRemote, Employee currentEmployee, ReservationControllerSessionBeanRemote reservationControllerSessionBeanRemote, RoomAllocationSessionBeanRemote roomAllocationSessionBeanRemote) {
		this();
		this.roomManagementSessionBeanRemote = roomManagementSessionBeanRemote;
		this.currentEmployee = currentEmployee;
		this.reservationControllerSessionBeanRemote = reservationControllerSessionBeanRemote;
		this.roomAllocationSessionBeanRemote = roomAllocationSessionBeanRemote;

	}

	public void menuMain() {

		Scanner scanner = new Scanner(System.in);
		Integer response;

		while (true) {
			System.out.println("*** Hotel Reservation System (HoRS):: Hotel Operation ***\n");
			System.out.println("You are logged in as " + currentEmployee.getFirstName() + " " + currentEmployee.getLastName()
					+ " with " + currentEmployee.getEmployeeRoleEnum().toString() + " rights\n");

			if (currentEmployee.getEmployeeRoleEnum().equals(EmployeeRoleEnum.OPERATIONMANAGER)) {
				System.out.println("1: Create New Room Type");
				System.out.println("2: View Room Type Details");
				System.out.println("3: View All Room Types");
				System.out.println("4: Create New Room");
				System.out.println("5: Update Room");
				System.out.println("6: Delete Room");
				System.out.println("7: View All Rooms");
				System.out.println("8: View Allocation Exception Report");
				System.out.println("9: Do Manual Allocation");
				System.out.println("10: Logout\n");

				System.out.print("> ");
				response = scanner.nextInt();

				switch (response) {
					case 1:
						doCreateNewRoomType();
						break;
					case 2:
						doViewRoomTypeDetails();
						break;
					case 3:
						doViewAllRoomTypes();
						break;
					case 4:
						doCreateNewRoom();
						break;
					case 5:
						doUpdateRoom();
						break;
					case 6:
						doDeleteRoom();
						break;
					case 7:
						doViewAllRooms();
						break;
					case 8:
						doViewRoomAllocationExceptionReport();
						break;
					case 9:
						doRoomAllocationManual();
						break;
					case 10:
						System.out.println("Logging out...\n");
						return;
					default:
						System.out.println("Invalid option, please try again!\n");
				}

			} else if (currentEmployee.getEmployeeRoleEnum().equals(EmployeeRoleEnum.SALESMANAGER)) {
				System.out.println("1: Create New Room Rate");
				System.out.println("2: View Room Rate Details");
				System.out.println("3: View All Room Rates");
				System.out.println("4: Logout\n");

				System.out.print("> ");
				response = scanner.nextInt();
				switch (response) {
					case 1:
						doCreateNewRoomRate();
						break;
					case 2:
						doViewRoomRateDetails();
						break;
					case 3:
						doViewAllRoomRates();
						break;
					case 4:
						System.out.println("Logging out...\n");
						return;
					default:
						System.out.println("Invalid option, please try again!\n");
				}

			} else {
				System.out.println("No valid role found. Please contact system administrator.");
				break;
			}
		}
	}

	public void doCreateNewRoomType() {
		Scanner scanner = new Scanner(System.in);
		RoomType newRoomType = new RoomType();

		System.out.println("*** Hotel Reservation System (HoRS) :: Hotel Operation :: Create New Room Type ***\n");
		System.out.print("Enter Room Type Name> ");
		newRoomType.setName(scanner.nextLine().trim());
		System.out.print("Enter Room Type Description> ");
		newRoomType.setDescription(scanner.nextLine().trim());
		System.out.print("Enter Room Type Size> ");
		newRoomType.setRoomSize(scanner.nextLine().trim());
		System.out.print("Enter Room Type Bed> ");
		newRoomType.setBed(scanner.nextLine().trim());

		while (true) {
			System.out.print("Enter Room Type Capacity> ");
			try {
				int capacity = Integer.parseInt(scanner.nextLine().trim());
				newRoomType.setCapacity(capacity);
				break;
			} catch (NumberFormatException e) {
				System.out.println("Invalid input for capacity. Please enter a valid number.");
			}
		}
		System.out.print("Enter Room Type Amenities> ");
		newRoomType.setAmenities(scanner.nextLine().trim());
		newRoomType.setStatus(StatusEnum.AVAILABLE);

		int newRanking;
		while (true) {
			System.out.print("Enter Room Type Rank (1 is the lowest rank)> ");
			try {
				newRanking = Integer.parseInt(scanner.nextLine().trim());
				newRoomType.setRanking(newRanking);
				break;
			} catch (NumberFormatException e) {
				System.out.println("Invalid input for rank. Please enter a valid number.");
			}
		}

		List<RoomType> roomTypes = roomManagementSessionBeanRemote.retrieveAllRoomTypes();
		if (!roomTypes.isEmpty()) {
			// Sort room types by ranking (ascending)
			roomTypes.sort(Comparator.comparing(RoomType::getRanking));

			for (RoomType existingRoomType : roomTypes) {
				// Shift ranks up for room types with equal or higher rank than the new one
				if (existingRoomType.getRanking() >= newRanking) {
					existingRoomType.setRanking(existingRoomType.getRanking() + 1);
					try {
						roomManagementSessionBeanRemote.updateRoomType(existingRoomType);
					} catch (RoomTypeNotFoundException | UpdateRoomTypeException ex) {
						System.out.println(ex.getMessage());
					}
				}
			}
		}

		if (roomTypes.isEmpty()) {
			System.out.println("No existing room types found");
		} else {
			System.out.println("Available Room Types (1 is the lowest rank):");
			for (int i = 0; i < roomTypes.size(); i++) {
				RoomType rt = roomTypes.get(i);
				System.out.println((i + 1) + ": " + rt.getName() + " (Rank: " + rt.getRanking() + ")");
			}
		}

		System.out.print("Enter Next Higher Room Type (leave blank if none)> ");
		String input = scanner.nextLine().trim();

		if (!input.isEmpty()) {
			try {
				int selectedIndex = Integer.parseInt(input);
				if (selectedIndex >= 1 && selectedIndex <= roomTypes.size()) {
					RoomType nextHigherRoomType = roomTypes.get(selectedIndex - 1);
					newRoomType.setNextHigherRoomType(nextHigherRoomType);
				} else {
					System.out.println("Invalid selection. Please try again.");
				}
			} catch (NumberFormatException e) {
				System.out.println("Invalid input. Please enter a valid number.");
			}
		}
		
		Set<ConstraintViolation<RoomType>> constraintViolations = validator.validate(newRoomType);
		if (constraintViolations.isEmpty()) {
			try {
				Long newRoomTypeId = roomManagementSessionBeanRemote.createNewRoomType(newRoomType);
				System.out.println("New room type created successfully!: " + newRoomTypeId + "\n");
			} catch (DuplicateRoomTypeException ex) {
				System.out.println("An error has occurred while creating the new room type!: The room type already exists.\n");
			} catch (UnknownPersistenceException ex) {
				System.out.println("An unknown error has occurred while creating the new room type!: " + ex.getMessage() + "\n");
			}
		} else {
			showInputDataValidationErrorsForRoomTypeEntity(constraintViolations);
		}
	}

	public void doViewRoomTypeDetails() {
		Scanner scanner = new Scanner(System.in);
		int response = 0;

		System.out.println("*** Hotel Reservation System (HoRS) :: View Room Type Details ***\n");

		try {
			List<RoomType> roomTypes = roomManagementSessionBeanRemote.retrieveAllRoomTypes();

			if (roomTypes.isEmpty()) {
				System.out.println("There are no room types available in the system.");
			} else {
				for (int i = 0; i < roomTypes.size(); i++) {
					RoomType roomType = roomTypes.get(i);
					System.out.println((i + 1) + ": " + roomType.getName());
				}

				System.out.println("----------------------------------\n");
				System.out.print("Select a room type by number to view details> ");
				int choice = scanner.nextInt();

				if (choice >= 1 && choice <= roomTypes.size()) {
					RoomType selectedRoomType = roomManagementSessionBeanRemote.retrieveRoomType(roomTypes.get(choice - 1).getRoomTypeId());

					System.out.println("\nRoom Type Details:");
					System.out.println("Room Type ID: " + selectedRoomType.getRoomTypeId());
					System.out.println("Name: " + selectedRoomType.getName());
					System.out.println("Description: " + selectedRoomType.getDescription());
					System.out.println("Size: " + selectedRoomType.getRoomSize());
					System.out.println("Bed: " + selectedRoomType.getBed());
					System.out.println("Capacity: " + selectedRoomType.getCapacity());
					System.out.println("Amenities: " + selectedRoomType.getAmenities());
					System.out.println("Status: " + selectedRoomType.getStatus());
					System.out.println("Rank: " + selectedRoomType.getRanking());
					if (selectedRoomType.getNextHigherRoomType() != null) {
						System.out.println("Next Higher Room Type: " + selectedRoomType.getNextHigherRoomType().getName());
					}
					System.out.println("----------------------------------");
					System.out.println("1: Update Room Type");
					System.out.println("2: Delete Room Type");
					System.out.println("3: Back\n");
					System.out.print("> ");
					response = scanner.nextInt();

					if (response == 1) {
						doUpdateRoomType(selectedRoomType);
					} else if (response == 2) {
						doDeleteRoomType(selectedRoomType);
					}

				} else {
					System.out.println("Invalid choice. Please select a valid number.");
				}
			}

		} catch (RoomTypeNotFoundException e) {
			System.out.println("An error occurred while retrieving room types: " + e.getMessage());
		}
	}

	public void doUpdateRoomType(RoomType roomType) {
		Scanner scanner = new Scanner(System.in);
		String input;

		System.out.println("*** Hotel Reservation System (HoRS) :: Hotel Operation :: View Room Type Details :: Update Room Type ***\n");

		System.out.print("Enter Name (blank if no change)> ");
		input = scanner.nextLine().trim();
		if (input.length() > 0) {
			roomType.setName(input);
		}

		System.out.print("Enter Description (blank if no change)> ");
		input = scanner.nextLine().trim();
		if (input.length() > 0) {
			roomType.setDescription(input);
		}

		System.out.print("Enter Room Size (blank if no change)> ");
		input = scanner.nextLine().trim();
		if (input.length() > 0) {
			roomType.setRoomSize(input);
		}

		System.out.print("Enter Bed (blank if no change)> ");
		input = scanner.nextLine().trim();
		if (input.length() > 0) {
			roomType.setBed(input);
		}

		while (true) {
			System.out.print("Enter Capacity (blank if no change)> ");
			input = scanner.nextLine().trim();
			if (input.isEmpty()) {
				break;
			}

			try {
				int capacity = Integer.parseInt(input);
				roomType.setCapacity(capacity);
				break;
			} catch (NumberFormatException e) {
				System.out.println("Invalid input for capacity. Please enter a valid number.");
			}
		}

		System.out.print("Enter Amenities (blank if no change)> ");
		input = scanner.nextLine().trim();
		if (input.length() > 0) {
			roomType.setAmenities(input);
		}

		while (true) {
			System.out.print("Enter Rank (blank if no change)> ");
			input = scanner.nextLine().trim();
			if (input.isEmpty()) {
				break;
			}

			try {
				int rank = Integer.parseInt(input);
				roomType.setRanking(rank);
				break;
			} catch (NumberFormatException e) {
				System.out.println("Invalid input for capacity. Please enter a valid number.");
			}
		}

		List<RoomType> roomTypes = roomManagementSessionBeanRemote.retrieveAllRoomTypes();

		if (roomTypes.isEmpty()) {
			System.out.println("No existing room types found.");
		} else {
			System.out.println("Available Room Types (1 is the lowest rank):");
			for (int i = 0; i < roomTypes.size(); i++) {
				RoomType rt = roomTypes.get(i);
				System.out.println((i + 1) + ": " + rt.getName() + " (Rank: " + rt.getRanking() + ")");
			}

			System.out.print("Enter the number of the Next Higher Room Type (leave blank if no change)> ");
			input = scanner.nextLine().trim();

			if (!input.isEmpty()) {
				try {
					int selectedIndex = Integer.parseInt(input);
					if (selectedIndex >= 1 && selectedIndex <= roomTypes.size()) {
						RoomType nextHigherRoomType = roomTypes.get(selectedIndex - 1);
						roomType.setNextHigherRoomType(nextHigherRoomType);
					} else {
						System.out.println("Invalid selection. No changes made to Next Higher Room Type.");
					}
				} catch (NumberFormatException e) {
					System.out.println("Invalid input. Please enter a valid number.");
				}
			}
		}

		try {
			roomManagementSessionBeanRemote.updateRoomType(roomType);
			System.out.println("Room type updated successfully!\n");
		} catch (RoomTypeNotFoundException | UpdateRoomTypeException ex) {
			System.out.println("An error has occurred while updating room type: " + ex.getMessage() + "\n");
		}

	}

	public void doDeleteRoomType(RoomType roomType) {
		Scanner scanner = new Scanner(System.in);
		String input;

		System.out.println("*** Hotel Reservation System (HoRS) :: Hotel Operation :: View Room Type Details :: Delete Room Type ***\n");
		System.out.printf("Confirm Delete Room Type %s (Room Type ID: %d) (Enter 'Y' to Delete)> ", roomType.getName(), roomType.getRoomTypeId());
		input = scanner.nextLine().trim();

		if (input.equalsIgnoreCase("Y")) {
			try {
				roomManagementSessionBeanRemote.deleteRoomType(roomType.getRoomTypeId());
				System.out.println("Room Type deleted successfully!\n");
			} catch (RoomTypeNotFoundException | DeleteRoomTypeException ex) {
				System.out.println("An error occurred: " + ex.getMessage() + "\n");
			}
		} else {
			System.out.println("Room Type NOT deleted!\n");
		}
	}

	public void doViewAllRoomTypes() {
		System.out.println("*** Hotel Reservation System (HoRS) :: View All Room Types ***\n");

		try {
			List<RoomType> roomTypes = roomManagementSessionBeanRemote.retrieveAllRoomTypes();

			if (roomTypes.isEmpty()) {
				System.out.println("There are no room types available in the system.");
			} else {
				// Display each room type
				for (RoomType roomType : roomTypes) {
					System.out.println("Room Type ID: " + roomType.getRoomTypeId() + " Name: " + roomType.getName());
//					System.out.println("Name: " + roomType.getName());
//					System.out.println("Description: " + roomType.getDescription());
//					System.out.println("Size: " + roomType.getRoomSize());
//					System.out.println("Bed: " + roomType.getBed());
//					System.out.println("Capacity: " + roomType.getCapacity());
//					System.out.println("Amenities: " + roomType.getAmenities());
				}
				System.out.println("----------------------------------");
			}

		} catch (Exception e) {
			System.out.println("An error occurred while retrieving room types: " + e.getMessage());
		}
	}

	public void doCreateNewRoom() {
		Scanner scanner = new Scanner(System.in);
		Room newRoom = new Room();
		Long roomTypeID = null;

		System.out.println("*** Hotel Reservation System (HoRS) :: Hotel Operation :: Create New Room ***\n");
		while (true) {
			System.out.print("Enter Room Number > ");
			try {
				int roomNumber = Integer.parseInt(scanner.nextLine().trim());
				newRoom.setRoomNumber(roomNumber);
				break;
			} catch (NumberFormatException e) {
				System.out.println("Invalid input for capacity. Please enter a valid number.");
			}
		}

		doViewAllRoomTypes();

		while (true) {

			try {
				System.out.print("Select Room Type By Entering the Corresponding ID > ");
				String input = scanner.nextLine().trim();
				roomTypeID = Long.parseLong(input);
				roomManagementSessionBeanRemote.retrieveRoomType(roomTypeID);
				System.out.println("RoomType ID " + roomTypeID + " exists. Proceeding...");
				break;

			} catch (NumberFormatException e) {
				System.out.println("Invalid input. Please enter a valid number.");

			} catch (RoomTypeNotFoundException ex) {
				System.out.println("An unknown error has occurred while creating the new room!: " + ex.getMessage() + "\n");
			}
		}

		newRoom.setStatus(StatusEnum.AVAILABLE);

		try {
			Long newRoomId = roomManagementSessionBeanRemote.createNewRoom(roomTypeID, newRoom);
			System.out.println("New room created successfully!: " + newRoomId + "\n");
		} catch (RoomTypeNotFoundException | CreateNewRoomException | DuplicateRoomException ex) {
			System.out.println(ex.getMessage());
		}
	}

	public void doUpdateRoom() {
		Scanner scanner = new Scanner(System.in);
		String input;
		int roomNumber;

		System.out.println("*** Hotel Reservation System (HoRS) :: Hotel Operation :: Update Room ***\n");

		while (true) {
			System.out.print("Enter Room Number You Wish To Update> ");
			try {
				input = scanner.nextLine().trim();
				if (input.isEmpty()) {
					System.out.println("Room number cannot be empty. Please enter a valid number.");
					continue;
				}
				roomNumber = Integer.parseInt(input);
				break;
			} catch (NumberFormatException e) {
				System.out.println("Invalid input. Please enter a valid integer for the room number.");
			}
		}

		try {
			// Retrieve room by original room number
			Room roomSelected = roomManagementSessionBeanRemote.retrieveRoom(roomNumber);

			System.out.println("----------------------------------");
			System.out.println("Current room details are as follows: ");
			System.out.println("Room Number: " + roomSelected.getRoomNumber());
			System.out.println("Room Type: " + roomSelected.getRoomType().getName());
			System.out.println("Room Status: " + roomSelected.getStatus());
			System.out.println("----------------------------------\n");
			System.out.println("*** Update Room Details***\n");

			// Update room number if specified
			System.out.print("Enter Room Number (blank if no change)> ");
			input = scanner.nextLine().trim();
			if (!input.isEmpty()) {
				try {
					int newRoomNumber = Integer.parseInt(input);
					roomSelected.setRoomNumber(newRoomNumber);  // Update room number
				} catch (NumberFormatException e) {
					System.out.println("Invalid input. Room number not updated.");
				}
			}

			// Retrieve and set new room type
			List<RoomType> roomTypes = roomManagementSessionBeanRemote.retrieveAllRoomTypes();
			System.out.println("Available Room Types:");
			for (int i = 0; i < roomTypes.size(); i++) {
				System.out.println((i + 1) + ": " + roomTypes.get(i).getName());
			}

			System.out.print("\nEnter Corresponding Number of Room Type (blank if no change)> ");
			input = scanner.nextLine().trim();
			if (!input.isEmpty()) {
				try {
					int selectedIndex = Integer.parseInt(input) - 1;
					if (selectedIndex >= 0 && selectedIndex < roomTypes.size()) {
						RoomType selectedRoomType = roomTypes.get(selectedIndex);
						roomSelected.setRoomType(selectedRoomType);
						System.out.println("Room type updated to: " + selectedRoomType.getName());
					} else {
						System.out.println("Invalid selection. Room type not updated.");
					}
				} catch (NumberFormatException e) {
					System.out.println("Invalid input. Room type not updated.");
				}
			}

			// Update room status
			System.out.print("Enter Room Status (Blank if no change, 1: Active, 2: Disabled)> ");
			input = scanner.nextLine().trim();
			if (!input.isEmpty()) {
				try {
					int statusOption = Integer.parseInt(input);
					switch (statusOption) {
						case 1:
							roomSelected.setStatus(StatusEnum.AVAILABLE);
							break;
						case 2:
							roomSelected.setStatus(StatusEnum.DISABLED);
							break;
						default:
							System.out.println("Invalid option. Room status not updated.");
							break;
					}
				} catch (NumberFormatException e) {
					System.out.println("Invalid input. Room status not updated.");
				}
			}

			// Persist the updates
			roomManagementSessionBeanRemote.updateRoom(roomSelected);
			System.out.println("Room updated successfully!\n");

		} catch (RoomNotFoundException | UpdateRoomException e) {
			System.out.println("An error occurred while updating room: " + e.getMessage());
		}
	}

	public void doDeleteRoom() {
		Scanner scanner = new Scanner(System.in);
		String input;
		int roomNumber = 0;

		System.out.println("*** Hotel Reservation System (HoRS) :: Hotel Operation :: Delete Room ***\n");

		while (true) {
			System.out.print("Enter Room Number You Wish To Delete> ");

			try {
				input = scanner.nextLine().trim();

				if (input.isEmpty()) {
					System.out.println("Room number cannot be empty. Please enter a valid number.");
					continue;
				}

				roomNumber = Integer.parseInt(input);
				break;
			} catch (NumberFormatException e) {
				System.out.println("Invalid input. Please enter a valid integer for the room number.");
			}
		}

		try {
			roomManagementSessionBeanRemote.deleteRoom(roomNumber);
			System.out.println("Room " + roomNumber + " has been successfully deleted.");
		} catch (RoomNotFoundException | DeleteRoomException e) {
			System.out.println("An error occurred while attempting to delete the room: " + e.getMessage());
		}
	}

	public void doViewAllRooms() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("\"*** Hotel Reservation System (HoRS) :: Hotel Operation :: View All Rooms ***\\n\"");

		List<Room> rooms = roomManagementSessionBeanRemote.retrieveAllRooms();
		System.out.printf("%8s%20s%20s%20s\n", "Room ID", "Room Number", "Room Type", "Room Status");

		for (Room room : rooms) {
			System.out.printf("%8s%20s%20s%20s\n", room.getRoomId().toString(), room.getRoomNumber(), room.getRoomType().getName(), room.getStatus().toString());
		}

		System.out.print("Press any key to continue...> ");
		scanner.nextLine();
	}

	//Manual allocation of the room
	public void doRoomAllocationManual() {
		List<ReservationDetail> allocatedReservationDetails = new ArrayList<>(); // Initialize as an empty list

		// Initialize scanner and ask for check-in/check-out dates
		Scanner scanner = new Scanner(System.in);
		System.out.println("*** Hotel Reservation System (HoRS) :: Hotel Operation :: do Room Allocation ***\n");
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date checkInDate = null;

		// Input Date with Error Handling for Date Parsing
		while (checkInDate == null) {
			try {
				System.out.print("Enter check-in date (yyyy-MM-dd)> ");
				checkInDate = simpleDateFormat.parse(scanner.nextLine().trim());
			} catch (ParseException e) {
				System.out.println("Invalid Date Input. Please enter a date in the correct format (yyyy-MM-dd).");
			}
		}

		// Retrieve reservation details by date from unallocated reservation
		List<ReservationDetail> reservationDetails = reservationControllerSessionBeanRemote.retrieveReservationDetailsByDate(checkInDate);

		if (reservationDetails == null || reservationDetails.isEmpty()) {
			System.out.println("No reservations found for the entered date.");
			return; // Exit if no reservations are found
		} else {
			try {
				allocatedReservationDetails = roomAllocationSessionBeanRemote.retrieveReservationDetailByDate(checkInDate);
			} catch (AllocationReportNotFoundException ex) {
				System.out.println(ex);
			}
			// Proceed with allocation logic only if there are reservation details
			for (ReservationDetail reservations : reservationDetails) {
				Integer numOfRooms = reservations.getNumOfRooms();
				Long roomTypeId = reservations.getRoomType().getRoomTypeId();
				boolean isAlreadyAllocated = false;

				// Check each reservation against already allocated details
				for (ReservationDetail allocatedReservation : allocatedReservationDetails) {
					if (reservations.getReservationDetailId().equals(allocatedReservation.getReservationDetailId())) {
						isAlreadyAllocated = true;
						break;
					}
				}

				// Allocate only if not already allocated
				if (!isAlreadyAllocated) {
					roomAllocation(numOfRooms, roomTypeId, reservations, checkInDate);
					allocatedReservationDetails.add(reservations);
				} else {
					System.out.println("Reservation Id: " + reservations.getReservationDetailId() + " Reservation has already been allocated.");
				}
			}
		}
	}

	// Helper function of room Allocation
	public void roomAllocation(Integer numOfRooms, Long roomTypeId, ReservationDetail reservationDetail, Date checkInDate) {
		RoomType roomType;

		// Retrieve room type by roomTypeId
		try {
			roomType = roomManagementSessionBeanRemote.retrieveRoomType(roomTypeId);
			roomType.getRooms().size();

		} catch (RoomTypeNotFoundException ex) {
			System.out.println("Room type not found: " + ex.getMessage());
			return;
		}

		// Collecting all available rooms based on the room type
		List<Room> availableRooms = new ArrayList<>();
		List<Integer> allocatedRoomsRecord = new ArrayList<>();

		try {
			allocatedRoomsRecord = roomAllocationSessionBeanRemote.retrieveAListOfAllocatedRoomsNumber();
		} catch (RoomNotFoundException e) {
			System.out.println(e);
		}
		if (allocatedRoomsRecord != null && allocatedRoomsRecord.isEmpty()) {
			if (roomType.getRooms() != null) {
				availableRooms.addAll(roomType.getRooms());
			}
		} else {
			if (roomType.getRooms() != null) {
				for (Room room : roomType.getRooms()) {
					boolean isAllocated = false;
					if (allocatedRoomsRecord != null) {
						for (Integer allocatedRoom : allocatedRoomsRecord) {
							if (room.getRoomNumber().equals(allocatedRoom)) {
								isAllocated = true;
								break;
							}
						}
					}
					if (!isAllocated) {
						availableRooms.add(room);
					}
				}
			}
		}

		// Check if any rooms are available to allocate
		if (availableRooms.isEmpty()) {
			System.out.println("No available rooms for the selected room type.");
			//return;
		}

		// Allocate as many rooms as are available
		int roomCountToAllocate = Math.min(numOfRooms, availableRooms.size());
		List<Room> allocatedRooms = availableRooms.subList(0, roomCountToAllocate);

		System.out.println("Allocated rooms: " + allocatedRooms.size() + " room(s).");

		// Mark allocated rooms with an appropriate status (e.g., RESERVED_ALLOCATED)
		for (Room room : allocatedRooms) {

			try {
				AllocationReport allocationReport = new AllocationReport();

				allocationReport.setRoomNumber(room.getRoomNumber());
				allocationReport.setCheckInDate(checkInDate);

				allocationReport.setAllocationStatus(AllocationStatusEnum.ALLOCATED);

				//the culprit if things goes south
				roomAllocationSessionBeanRemote.createNewAllocationRecord(reservationDetail, allocationReport);
				// roomAllocationSessionBeanRemote.linkAllocationToReservation(reservationDetail,allocationReport);

				System.out.println("Room " + room.getRoomNumber() + " allocated and persisted.");
			} catch (Exception e) {
				System.out.println("Failed to persist room " + room.getRoomNumber() + ": " + e.getMessage());
			}

		}

		if (allocatedRooms.size() >= numOfRooms) {
			System.out.println("All required rooms have been allocated. No upgrade needed.");
			return; // Early return to avoid unnecessary upgrade logic
		}

		if (allocatedRooms.size() < numOfRooms) {
			int shortage = numOfRooms - allocatedRooms.size(); // Calculate the shortage
			System.out.println("Partial allocation: " + shortage + " more room(s) needed or unavailable.");
			System.out.println("Looking for an upgrade....");

			// Step 1: Prepare lists for upgraded rooms
			List<Room> upgradedRooms = new ArrayList<>();          // Rooms to be upgraded
			List<Integer> upgradeRoomRecord = new ArrayList<>();   // Record of rooms already upgraded/allocated
			List<Room> availableUpgradeRooms = new ArrayList<>();  // Rooms available for upgrading
			Integer upgradedRank = null;

			// Step 2: Fetch the next room rank (upgraded rooms)
			try {
				upgradedRank = roomManagementSessionBeanRemote.retrieveRoomType(roomTypeId).getRanking() + 1;
			} catch (RoomTypeNotFoundException ex) {
				System.out.println("Rank not found: " + ex.getMessage());
				return; // Exit in case of failure in retrieving the upgraded rank
			}

			// Step 3: Retrieve rooms of higher rank (upgraded rooms)
			try {
				upgradedRooms = roomManagementSessionBeanRemote.retrieveRoomsByRank(upgradedRank);
				if (upgradedRooms.isEmpty()) {
					System.out.println("No rooms found for the upgraded rank.");
					return;  // No rooms available for upgrade, so exit this block
				}
			} catch (RoomTypeNotFoundException e) {
				System.out.println("No RoomType Found for upgraded rank: " + e.getMessage());
				return;  // Exit in case of failure
			}

			// Step 4: Retrieve the list of rooms already upgraded or allocated
			try {
				upgradeRoomRecord = roomAllocationSessionBeanRemote.retrieveAListOfAllocatedRoomsNumber();
			} catch (RoomNotFoundException e) {
				System.out.println("Error retrieving allocated room numbers: " + e.getMessage());
			}

			// Step 5: Filter upgraded room list by removing rooms already allocated/upgraded
			for (Room room : upgradedRooms) {
				boolean isAlreadyAllocated = false;
				// Check if this room is already in the allocated list
				for (Integer allocatedRoomNumber : upgradeRoomRecord) {
					if (room.getRoomNumber().equals(allocatedRoomNumber)) {
						isAlreadyAllocated = true; // Mark as already allocated and skip
						break;
					}
				}
				// If the room is NOT allocated, add it to the available upgrade rooms list
				if (!isAlreadyAllocated) {
					availableUpgradeRooms.add(room);
				}
			}

			// Step 6: Validate if we have enough rooms to upgrade
			if (availableUpgradeRooms.size() < shortage) {
				// Not enough rooms for the upgrade, immediately mark as `NOT_UPGRADED`
				System.out.println("Not enough rooms are available for upgrade.");

				try {
					AllocationReport allocationReport = new AllocationReport();
					allocationReport.setAllocationStatus(AllocationStatusEnum.NOT_UPGRADED);
					allocationReport.setCheckInDate(checkInDate);
					roomAllocationSessionBeanRemote.createNewAllocationRecord(reservationDetail, allocationReport);
					System.out.println("Marked as NOT_UPGRADED due to insufficient upgradeable rooms.");
				} catch (Exception e) {
					System.out.println("Error generating NOT_UPGRADED report: " + e.getMessage());
				}

				return;  // Exit because we can't proceed with upgrading
			}

			// Step 7: Allocate rooms as there are enough available upgrade rooms
			int roomsToUpgrade = shortage;  // Since shortage == availableUpgradeRooms.size() has been validated
			List<Room> allocatedUpgradedRooms = availableUpgradeRooms.subList(0, roomsToUpgrade);

			System.out.println("Allocated upgraded rooms: " + allocatedUpgradedRooms.size() + " room(s).");

			// Step 8: Mark upgraded rooms and persist them
			for (Room upgradeRoom : allocatedUpgradedRooms) {
				try {
					// Create the allocation report for each upgraded room
					AllocationReport allocationReport = new AllocationReport();
					allocationReport.setRoomNumber(upgradeRoom.getRoomNumber());
					allocationReport.setCheckInDate(checkInDate);
					allocationReport.setAllocationStatus(AllocationStatusEnum.UPGRADED);

					// Persist the newly upgraded record
					roomAllocationSessionBeanRemote.createNewAllocationRecord(reservationDetail, allocationReport);
					System.out.println("Room " + upgradeRoom.getRoomNumber() + " upgraded and persisted.");
				} catch (Exception e) {
					System.out.println("Failed to upgrade room " + upgradeRoom.getRoomNumber() + ": " + e.getMessage());
				}
			}

		} else {
			// No upgrade needed; just handle as necessary
			try {
				AllocationReport allocationReport = new AllocationReport();
				allocationReport.setAllocationStatus(AllocationStatusEnum.NOT_UPGRADED);
				roomAllocationSessionBeanRemote.createNewAllocationRecord(reservationDetail, allocationReport);
				System.out.println("Marked as NOT_UPGRADED since no upgrade was required.");
			} catch (Exception e) {
				System.out.println("Error generating NOT_UPGRADED report: " + e.getMessage());
			}
		}
	}

	public void doViewRoomAllocationExceptionReport() {
		System.out.println("*** Hotel Reservation System (HoRS) :: Hotel Operation :: Delete Room ***\n");
		System.out.println("Reservations that are upgraded");
		System.out.println("----------------------------------");
		List<AllocationReport> allocationReports = new ArrayList<>();
		try {
			allocationReports = roomAllocationSessionBeanRemote.retrieveAListOfUpgradedReservation();
		} catch (RoomNotFoundException e) {
			System.out.println(e);
		}
		for (AllocationReport allocationReport : allocationReports) {
			List<ReservationDetail> reservationDetails = allocationReport.getReservationDetail();
			for (ReservationDetail reservationDetail : reservationDetails) {
				System.out.println("Reservation Id: " + reservationDetail.getReservationDetailId() + " RoomNumber: " + allocationReport.getRoomNumber() + " CheckInDate: " + allocationReport.getCheckInDate());
			}

		}
		System.out.println("******************************************");
		System.out.println("Reservations that are unable to upgraded");
		System.out.println("----------------------------------");
		List<AllocationReport> allocationNotUpgradedReports = new ArrayList<>();
		try {
			allocationNotUpgradedReports = roomAllocationSessionBeanRemote.retrieveAListOfNotUpgradedReservation();
		} catch (RoomNotFoundException e) {
			System.out.println(e);
		}
		for (AllocationReport allocationReport : allocationNotUpgradedReports) {
			List<ReservationDetail> reservationDetails = allocationReport.getReservationDetail();
			for (ReservationDetail reservationDetail : reservationDetails) {
				System.out.println("Reservation Id: " + reservationDetail.getReservationDetailId() + " CheckInDate: " + allocationReport.getCheckInDate());
			}

		}
		System.out.println("----------------------------------");

	}

	public void doCreateNewRoomRate() {
		Scanner scanner = new Scanner(System.in);
		RoomRate newRoomRate = new RoomRate();
		Long roomTypeId = null;

		System.out.println("*** Hotel Reservation System (HoRS) :: Hotel Operation :: Create New Room Rate ***\n");
		while (true) {
			try {
				doViewAllRoomTypes();
				System.out.print("Please enter the RoomType Id you want to create rate for> ");
				String input = scanner.nextLine().trim();
				roomTypeId = Long.parseLong(input);

				try {
					roomManagementSessionBeanRemote.retrieveRoomType(roomTypeId); // Check for valid RoomType ID
					System.out.println("RoomType ID " + roomTypeId + " exists. Proceeding...");
					break;
				} catch (RoomTypeNotFoundException e) {
					System.out.println(e.getMessage());
					System.out.println("Cannot proceed without a valid RoomType.");
					return;
				}

			} catch (NumberFormatException e) {
				System.out.println("Invalid input. Please enter a numeric RoomType ID.");
			}
		}

		System.out.print("Enter Rate Name> ");
		String rateName = scanner.nextLine().trim();
		if (rateName.isEmpty()) {
			System.out.println("Rate Name cannot be empty!");
			return; // Exit early if rate name is empty
		}
		newRoomRate.setName(rateName);

		// Select Room Rate Type
		while (true) {
			System.out.print("Select Room Rate Type (1: Published, 2: Normal, 3: Peak, 4: Promotion) > ");
			if (!scanner.hasNextInt()) {
				System.out.println("Invalid input. Please enter a number.");
				scanner.next(); // Clear invalid input
				continue;
			}
			int roomRateInt = scanner.nextInt();
			if (roomRateInt >= 1 && roomRateInt <= 4) {
				RateTypeEnum selectedRateType = RateTypeEnum.values()[roomRateInt - 1];
				newRoomRate.setRateType(selectedRateType);
				break;
			} else {
				System.out.println("Invalid option, please try again!");
			}
		}
		scanner.nextLine(); // Consume newline

		while (true) {
			System.out.print("Enter Rate Per Night > ");
			try {
				BigDecimal ratePerNight = new BigDecimal(scanner.nextLine().trim());
				newRoomRate.setRatePerNight(ratePerNight);
				break; // Exit the loop once a valid rate is entered
			} catch (NumberFormatException e) {
				System.out.println("Invalid input for rate per night. Please enter a valid number.");
			}
		}

		// Handle Date Inputs for Peak or Promotion types
		if (newRoomRate.getRateType() == RateTypeEnum.PEAK || newRoomRate.getRateType() == RateTypeEnum.PROMOTION) {
			DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

			// Start Date
			LocalDate startLocalDate = null;
			while (true) {
				System.out.print("Enter Start Date for Peak/Promotion (yyyy-MM-dd) > ");
				String startDateInput = scanner.nextLine().trim();
				if (startDateInput.isEmpty()) {
					System.out.println("Start date cannot be empty!");
					continue;
				}
				try {
					startLocalDate = LocalDate.parse(startDateInput, dateFormatter);
					break;
				} catch (DateTimeParseException e) {
					System.out.println("Invalid date format. Please enter in yyyy-MM-dd format.");
				}
			}

			// End Date
			LocalDate endLocalDate = null;
			while (true) {
				System.out.print("Enter End Date for Peak/Promotion (yyyy-MM-dd) > ");
				String endDateInput = scanner.nextLine().trim();
				if (endDateInput.isEmpty()) {
					System.out.println("End date cannot be empty!");
					continue;
				}
				try {
					endLocalDate = LocalDate.parse(endDateInput, dateFormatter);
					if (endLocalDate.isBefore(startLocalDate)) {
						System.out.println("End date must be after start date. Please try again.");
					} else {
						break;
					}
				} catch (DateTimeParseException e) {
					System.out.println("Invalid date format. Please enter in yyyy-MM-dd format.");
				}
			}

			// Convert LocalDate to Date and set them
			newRoomRate.setValidityPeriodStart(Date.from(startLocalDate.atStartOfDay(ZoneId.systemDefault()).toInstant()));
			newRoomRate.setValidityPeriodEnd(Date.from(endLocalDate.atStartOfDay(ZoneId.systemDefault()).toInstant()));
		}

		// Set default status
		newRoomRate.setStatus(StatusEnum.AVAILABLE);

		// Display validation details
		System.out.println("New Room Rate Details:");
		System.out.println("Name: " + newRoomRate.getName());
		System.out.println("Rate Type: " + newRoomRate.getRateType());
		System.out.println("Rate Per Night: " + newRoomRate.getRatePerNight());
		System.out.println("Validity Start: " + newRoomRate.getValidityPeriodStart());
		System.out.println("Validity End: " + newRoomRate.getValidityPeriodEnd());
		System.out.println("Status: " + newRoomRate.getStatus());

		Set<ConstraintViolation<RoomRate>> constraintViolations = validator.validate(newRoomRate);
		
		if (constraintViolations.isEmpty()) {
			try {
				Long newRoomRateId = roomManagementSessionBeanRemote.createNewRoomRate(roomTypeId, newRoomRate);
				System.out.println("New room rate created successfully! ID: " + newRoomRateId);
			} catch (Exception e) {
				System.out.println("Failed to create new room rate: " + e.getMessage());
				e.printStackTrace(); // Log stack trace for debugging
			}
		} else {
			showInputDataValidationErrorsForRoomRateEntity(constraintViolations);
		}
	}

	public void doViewRoomRateDetails() {
		Scanner scanner = new Scanner(System.in);
		int response = 0;
		System.out.println("*** Hotel Reservation System (HoRS) :: View Room Rate Details ***\n");

		try {
			List<RoomRate> roomRates = roomManagementSessionBeanRemote.retrieveAllRoomRates();

			if (roomRates.isEmpty()) {
				System.out.println("There are no room rates available in the system.");
			} else {
				for (int i = 0; i < roomRates.size(); i++) {
					RoomRate roomRate = roomRates.get(i);
					System.out.println((i + 1) + ": " + roomRate.getName());
				}

				System.out.println("----------------------------------\n");
				System.out.print("Select a room rates by number to view details> ");
				int choice = scanner.nextInt();

				if (choice >= 1 && choice <= roomRates.size()) {
					RoomRate selectedRoomRate = roomManagementSessionBeanRemote.retrieveRoomRate(roomRates.get(choice - 1).getRoomRateId());

					System.out.println("\nRoom Type Details:");
					System.out.println("Room Type ID: " + selectedRoomRate.getRoomRateId());
					System.out.println("Name: " + selectedRoomRate.getName());
					System.out.println("rateType " + selectedRoomRate.getRateType());
					System.out.println("ratePerNight: " + selectedRoomRate.getRatePerNight());
					System.out.println("Validity Start Date: " + selectedRoomRate.getValidityPeriodStart());
					System.out.println("Validity End Date " + selectedRoomRate.getValidityPeriodEnd());
					System.out.println("Status: " + selectedRoomRate.getStatus());
					System.out.println("----------------------------------");
					System.out.println("1: Update Room Rate");
					System.out.println("2: Delete Room Rate");
					System.out.println("3: Back\n");
					System.out.print("> ");
					response = scanner.nextInt();

					if (response == 1) {
						doUpdateRoomRate(selectedRoomRate);
					} else if (response == 2) {
						doDeleteRoomRate(selectedRoomRate);
					}

				} else {
					System.out.println("Invalid choice. Please select a valid number.");
				}
			}

		} catch (RoomRateNotFoundException e) {
			System.out.println("An error occurred while retrieving room types: " + e.getMessage());
		}
	}

	public void doUpdateRoomRate(RoomRate roomRate) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter Rate Name (Leave blank to keep current) > ");
		String rateName = scanner.nextLine().trim();
		if (!rateName.isEmpty()) {
			roomRate.setName(rateName);
		}

// Setting Room Rate Type
		while (true) {
			System.out.print("Select Room Rate Type (1: Published, 2: Normal, 3: Peak, 4: Promotion) (Leave blank to keep current) > ");
			String input = scanner.nextLine().trim();
			if (input.isEmpty()) {
				break; // Retain current rate type if blank
			}
			try {
				int roomRateInt = Integer.parseInt(input);
				if (roomRateInt >= 1 && roomRateInt <= 4) {
					RateTypeEnum selectedRateType = RateTypeEnum.values()[roomRateInt - 1];
					roomRate.setRateType(selectedRateType);
					break;
				} else {
					System.out.println("Invalid option, please try again!");
				}
			} catch (NumberFormatException e) {
				System.out.println("Invalid input. Please enter a number.");
			}
		}

// Setting Rate Per Night
		while (true) {
			System.out.print("Enter Rate Per Night (Leave blank to keep current) > ");
			String input = scanner.nextLine().trim();
			if (input.isEmpty()) {
				break; // Retain current rate per night if blank
			}
			try {
				BigDecimal ratePerNight = new BigDecimal(input);
				roomRate.setRatePerNight(ratePerNight);
				break;
			} catch (NumberFormatException e) {
				System.out.println("Invalid input for rate per night. Please enter a valid number.");
			}
		}

		if (roomRate.getRateType() == RateTypeEnum.PUBLISHED || roomRate.getRateType() == RateTypeEnum.NORMAL) {
			roomRate.setValidityPeriodStart(null);
			roomRate.setValidityPeriodEnd(null);
		}

// If Peak or Promotion, handle Date Inputs
		if (roomRate.getRateType() == RateTypeEnum.PEAK || roomRate.getRateType() == RateTypeEnum.PROMOTION) {
			DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

			// Start Date
			while (true) {
				System.out.print("Enter Start Date for Peak/Promotion (yyyy-MM-dd) (Leave blank to keep current) > ");
				String startDateInput = scanner.nextLine().trim();
				if (startDateInput.isEmpty()) {
					break; // Retain current start date if blank
				}
				try {
					LocalDate startLocalDate = LocalDate.parse(startDateInput, dateFormatter);
					roomRate.setValidityPeriodStart(Date.from(startLocalDate.atStartOfDay(ZoneId.systemDefault()).toInstant()));
					break;
				} catch (DateTimeParseException e) {
					System.out.println("Invalid date format. Please enter in yyyy-MM-dd format.");
				}
			}

			// End Date
			while (true) {
				System.out.print("Enter End Date for Peak/Promotion (yyyy-MM-dd) (Leave blank to keep current) > ");
				String endDateInput = scanner.nextLine().trim();
				if (endDateInput.isEmpty()) {
					break; // Retain current end date if blank
				}
				try {
					LocalDate endLocalDate = LocalDate.parse(endDateInput, dateFormatter);
					if (!roomRate.getValidityPeriodStart().before(Date.from(endLocalDate.atStartOfDay(ZoneId.systemDefault()).toInstant()))) {
						System.out.println("End date must be after start date. Please try again.");
						continue;
					}
					roomRate.setValidityPeriodEnd(Date.from(endLocalDate.atStartOfDay(ZoneId.systemDefault()).toInstant()));
					break;
				} catch (DateTimeParseException e) {
					System.out.println("Invalid date format. Please enter in yyyy-MM-dd format.");
				}
			}
		}

// Update Room Rate
		try {
			roomManagementSessionBeanRemote.updateRoomRate(roomRate);
			System.out.println("Room Rate Updated Successfully");
		} catch (RoomRateNotFoundException | UpdateRoomRateException ex) {
			System.out.println("Failed to update room rate: " + ex.getMessage());
		}

	}

	public void doDeleteRoomRate(RoomRate roomRate) {
		Scanner scanner = new Scanner(System.in);
		String input;

		System.out.println("*** Hotel Reservation System (HoRS) :: Hotel Operation :: View Room Type Details :: Delete Room Type ***\n");
		System.out.printf("Confirm Delete Room Type %s (Room Type ID: %d) (Enter 'Y' to Delete)> ", roomRate.getName(), roomRate.getRoomRateId());
		input = scanner.nextLine().trim();

		if (input.equalsIgnoreCase("Y")) {
			try {
				roomManagementSessionBeanRemote.deleteRoomRate(roomRate.getRoomRateId());
				System.out.println("Room Type deleted successfully!\n");
			} catch (RoomRateNotFoundException | DeleteRoomRateException ex) {
				System.out.println("An error occurred: " + ex.getMessage() + "\n");
			}
		} else {
			System.out.println("Room Rate NOT deleted!\n");
		}
	}

	public void doViewAllRoomRates() {
		System.out.println("*** Hotel Reservation System (HoRS) :: View All Room Rates ***\n");

		try {
			List<RoomRate> roomRate = roomManagementSessionBeanRemote.retrieveAllRoomRates();

			if (roomRate.isEmpty()) {
				System.out.println("There are no room types available in the system.");
			} else {
				// Display each room type
				for (RoomRate roomRates : roomRate) {
					System.out.println("Room Type ID: " + roomRates.getRoomRateId() + " Name: " + roomRates.getName());
				}

				System.out.println("----------------------------------");
			}

		} catch (Exception e) {
			System.out.println("An error occurred while retrieving room types: " + e.getMessage());
		}
	}

	private void showInputDataValidationErrorsForRoomTypeEntity(Set<ConstraintViolation<RoomType>> constraintViolations) {
		System.out.println("\nInput data validation error!:");

		for (ConstraintViolation constraintViolation : constraintViolations) {
			System.out.println("\t" + constraintViolation.getPropertyPath() + " - " + constraintViolation.getInvalidValue() + constraintViolation.getMessage());
		}

		System.out.println("\nPlease try again......\n");
	}
	
	private void showInputDataValidationErrorsForRoomRateEntity(Set<ConstraintViolation<RoomRate>> constraintViolations) {
		System.out.println("\nInput data validation error!:");

		for (ConstraintViolation constraintViolation : constraintViolations) {
			System.out.println("\t" + constraintViolation.getPropertyPath() + " - " + constraintViolation.getInvalidValue() + constraintViolation.getMessage());
		}

		System.out.println("\nPlease try again......\n");
	}
}
