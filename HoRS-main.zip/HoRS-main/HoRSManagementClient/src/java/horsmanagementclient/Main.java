package horsmanagementclient;

import ejb.session.stateless.EmployeeSessionBeanRemote;
import ejb.session.stateless.PartnerEmployeeSessionBeanRemote;
import ejb.session.stateless.RoomManagementSessionBeanRemote;
import javax.ejb.EJB;
import ejb.session.stateless.ReservationControllerSessionBeanRemote;
import ejb.session.stateless.RoomAllocationSessionBeanRemote;
import ejb.session.stateless.SchedulerSessionBeanRemote;
import ejb.session.stateless.WalkInReservationSessionBeanRemote;


public class Main {

	@EJB
	private static SchedulerSessionBeanRemote schedulerSessionBeanRemote;

	@EJB
	private static RoomAllocationSessionBeanRemote roomAllocationSessionBeanRemote;

	@EJB
	private static EmployeeSessionBeanRemote employeeSessionBeanRemote;

	@EJB
	private static PartnerEmployeeSessionBeanRemote partnerEmployeeSessionBeanRemote;

	@EJB
	private static RoomManagementSessionBeanRemote roomManagementSessionBeanRemote;

	@EJB
	private static ReservationControllerSessionBeanRemote reservationControllerSessionBeanRemote;

	@EJB
	private static WalkInReservationSessionBeanRemote walkInReservationSessionBeanRemote;

	public static void main(String[] args) {

		MainApp mainApp = new MainApp(employeeSessionBeanRemote, partnerEmployeeSessionBeanRemote, roomManagementSessionBeanRemote, reservationControllerSessionBeanRemote, walkInReservationSessionBeanRemote, roomAllocationSessionBeanRemote, schedulerSessionBeanRemote);
		mainApp.runApp();
	}
}
