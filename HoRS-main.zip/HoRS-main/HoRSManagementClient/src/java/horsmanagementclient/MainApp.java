package horsmanagementclient;

import ejb.session.stateless.EmployeeSessionBeanRemote;
import ejb.session.stateless.PartnerEmployeeSessionBeanRemote;
import ejb.session.stateless.RoomManagementSessionBeanRemote;
import entity.Employee;
import java.util.Scanner;
import util.enumeration.EmployeeRoleEnum;
import util.exception.InvalidLoginCredentialException;
import ejb.session.stateless.ReservationControllerSessionBeanRemote;
import ejb.session.stateless.RoomAllocationSessionBeanRemote;
import ejb.session.stateless.SchedulerSessionBeanRemote;
import ejb.session.stateless.WalkInReservationSessionBeanRemote;

public class MainApp {

	private EmployeeSessionBeanRemote employeeSessionBeanRemote;
	private PartnerEmployeeSessionBeanRemote partnerEmployeeSessionBeanRemote;
	private RoomManagementSessionBeanRemote roomManagementSessionBeanRemote;
	private ReservationControllerSessionBeanRemote reservationControllerSessionBeanRemote;
	private WalkInReservationSessionBeanRemote walkInReservationSessionBeanRemote;
	private SchedulerSessionBeanRemote schedulerSessionBeanRemote;
	private Employee currentEmployee;
	private RoomAllocationSessionBeanRemote roomAllocationSessionBeanRemote;

	private SystemAdministrationModule systemAdministrationModule;
	private HotelOperationModule hotelOperationModule;
	private FrontOfficeModule frontOfficeModule;

	public MainApp() {
	}

	public MainApp(EmployeeSessionBeanRemote employeeSessionBeanRemote, PartnerEmployeeSessionBeanRemote partnerEmployeeSessionBeanRemote, RoomManagementSessionBeanRemote roomManagementSessionBeanRemote, ReservationControllerSessionBeanRemote reservationControllerSessionBeanRemote, WalkInReservationSessionBeanRemote walkInReservationSessionBeanRemote, RoomAllocationSessionBeanRemote roomAllocationSessionBeanRemote, SchedulerSessionBeanRemote schedulerSessionBeanRemote) {
		this.employeeSessionBeanRemote = employeeSessionBeanRemote;
		this.partnerEmployeeSessionBeanRemote = partnerEmployeeSessionBeanRemote;
		this.roomManagementSessionBeanRemote = roomManagementSessionBeanRemote;
		this.reservationControllerSessionBeanRemote = reservationControllerSessionBeanRemote;
		this.walkInReservationSessionBeanRemote = walkInReservationSessionBeanRemote;
		this.roomAllocationSessionBeanRemote = roomAllocationSessionBeanRemote;
		this.schedulerSessionBeanRemote = schedulerSessionBeanRemote;
	}

	public void runApp() {
		Scanner scanner = new Scanner(System.in);
		Integer response = 0;
		schedulerSessionBeanRemote.automatedRoomAllocation();

		while (true) {
			System.out.println("*** Welcome to Hotel Reservation System (HoRS)***\n");
			System.out.println("1: Login");
			System.out.println("2: Exit\n");
			response = 0;

			while (response < 1 || response > 2) {
				System.out.print("> ");

				String input = scanner.nextLine().trim();

				try {
					response = Integer.parseInt(input);

					if (response == 1) {
						try {
							doLogin();
							System.out.println("Login successful!\n");
							loadMenuByRole();

						} catch (InvalidLoginCredentialException ex) {
							System.out.println("Invalid login credential: " + ex.getMessage() + "\n");
						}
					} else if (response == 2) {
						break;
					} else {
						System.out.println("Invalid option, please try again!\n");
					}
				} catch (NumberFormatException ex) {
					System.out.println("Invalid input. Please enter a valid number.\n");
				}

			}

			if (response == 2) {
				break;
			}

		}
	}

	private void doLogin() throws InvalidLoginCredentialException {
		Scanner scanner = new Scanner(System.in);
		String username = "";
		String password = "";

		System.out.println("*** Hotel Reservation System (HoRS) :: Login ***\n");
		System.out.print("Enter username> ");
		username = scanner.nextLine().trim();
		System.out.print("Enter password> ");
		password = scanner.nextLine().trim();

		if (username.length() > 0 && password.length() > 0) {
			currentEmployee = employeeSessionBeanRemote.employeeLogin(username, password);
		} else {
			throw new InvalidLoginCredentialException("Missing login credential!");
		}
	}

	public void loadMenuByRole() {
		EmployeeRoleEnum role = currentEmployee.getEmployeeRoleEnum();

		if (role == EmployeeRoleEnum.SYSTEMADMINISTRATOR) {
			systemAdministrationModule = new SystemAdministrationModule(employeeSessionBeanRemote, partnerEmployeeSessionBeanRemote, currentEmployee);
			systemAdministrationModule.menuMain();
		} else if (role == EmployeeRoleEnum.OPERATIONMANAGER | role == EmployeeRoleEnum.SALESMANAGER) {
			hotelOperationModule = new HotelOperationModule(roomManagementSessionBeanRemote, currentEmployee, reservationControllerSessionBeanRemote, roomAllocationSessionBeanRemote);
			hotelOperationModule.menuMain();
		} else if (role == EmployeeRoleEnum.GUESTRELATIONOFFICER) {
			frontOfficeModule = new FrontOfficeModule(roomManagementSessionBeanRemote, reservationControllerSessionBeanRemote, walkInReservationSessionBeanRemote, roomAllocationSessionBeanRemote, currentEmployee);
			frontOfficeModule.menuMain();
		} else {
			System.out.println("Access Denied: Unknown role or insufficient privileges.");
		}
	}

}
