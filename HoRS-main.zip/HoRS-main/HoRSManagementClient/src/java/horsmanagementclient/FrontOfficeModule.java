package horsmanagementclient;

import ejb.session.stateless.RoomManagementSessionBeanRemote;
import entity.Employee;
import entity.ReservationDetail;
import entity.Room;
import entity.RoomType;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import util.enumeration.StatusEnum;
import ejb.session.stateless.ReservationControllerSessionBeanRemote;
import ejb.session.stateless.RoomAllocationSessionBeanRemote;
import ejb.session.stateless.WalkInReservationSessionBeanRemote;
import entity.AllocationReport;
import entity.Reservation;
import entity.WalkInReservation;
import java.math.BigDecimal;
import java.util.ArrayList;
import javax.persistence.NoResultException;
import util.enumeration.AllocationStatusEnum;
import util.exception.AllocationReportNotFoundException;

public class FrontOfficeModule {

	private RoomManagementSessionBeanRemote roomManagementSessionBeanRemote;
	private ReservationControllerSessionBeanRemote reservationControllerSessionBeanRemote;
	private WalkInReservationSessionBeanRemote walkInReservationSessionBeanRemote;
	private RoomAllocationSessionBeanRemote roomAllocationSessionBeanRemote;
	private Employee currentEmployee;

	public FrontOfficeModule() {
	}

	public FrontOfficeModule(RoomManagementSessionBeanRemote roomManagementSessionBeanRemote, ReservationControllerSessionBeanRemote reservationControllerSessionBeanRemote, WalkInReservationSessionBeanRemote walkInReservationSessionBeanRemote, RoomAllocationSessionBeanRemote roomAllocationSessionBeanRemote, Employee currentEmployee) {
		this();
		this.roomManagementSessionBeanRemote = roomManagementSessionBeanRemote;
		this.reservationControllerSessionBeanRemote = reservationControllerSessionBeanRemote;
		this.walkInReservationSessionBeanRemote = walkInReservationSessionBeanRemote;
		this.roomAllocationSessionBeanRemote = roomAllocationSessionBeanRemote;
		this.currentEmployee = currentEmployee;
	}

	public void menuMain() {

		Scanner scanner = new Scanner(System.in);
		Integer response = 0;

		while (true) {
			System.out.println("*** Hotel Reservation System (HoRS):: Front Office ***\n");
			System.out.println("You are login as " + currentEmployee.getFirstName() + " " + currentEmployee.getLastName() + " with " + currentEmployee.getEmployeeRoleEnum().toString() + " rights\n");
			System.out.println("1: Walk-in Search Room");
			System.out.println("2: Check-in Guest");
			System.out.println("3: Check-out Guest");
			System.out.println("4: Logout\n");
			response = 0;

			while (response < 1 || response > 4) {
				System.out.print("> ");

				response = scanner.nextInt();

				if (response == 1) {
					doWalkinSearch();
				} else if (response == 2) {
					doCheckin();
				} else if (response == 3) {
					doCheckout();
				} else if (response == 4) {
					break;
				} else {
					System.out.println("Invalid option, please try again!\n");
				}
			}

			if (response == 4) {
				break;
			}
		}
	}

	public void doWalkinSearch() {
		try {
			Scanner scanner = new Scanner(System.in);
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

			System.out.println("*** Hotel Reservation System (HoRS) :: Front Office :: Walk-in Search Room ***\n");

			System.out.print("Enter check-in date (yyyy-MM-dd)> ");
			Date checkInDate = simpleDateFormat.parse(scanner.nextLine().trim());
			System.out.print("Enter check-out date (yyyy-MM-dd)> ");
			Date checkOutDate = simpleDateFormat.parse(scanner.nextLine().trim());

			List<RoomType> roomTypes = roomManagementSessionBeanRemote.retrieveAllRoomTypes();
			boolean hasAvailableRooms = false;
			int index = 1;

			System.out.println("\nAvailable Room Types:");

			// Iterate through all room types to calculate available rooms
			for (RoomType roomType : roomTypes) {
				
				if (roomType.getRoomRates().isEmpty()) {
					continue; // Skip room types without associated room rates
				}
				
				int totalRooms = roomType.getRooms().size();
				int availableRooms = totalRooms;

				//	 Deduct rooms that are not in an inactive status (disabled or unavailable)
				for (Room room : roomType.getRooms()) {
					if (room.getStatus().equals(StatusEnum.DISABLED)) {
						availableRooms--;
					}
				}

				// Deduct rooms based on overlapping reservations
				List<ReservationDetail> reservations = reservationControllerSessionBeanRemote.retrieveReservationDetailsByRoomTypeAndDate(roomType, checkInDate, checkOutDate);
				for (ReservationDetail reservationDetail : reservations) {
					availableRooms -= reservationDetail.getNumOfRooms();
				}

				if (availableRooms > 0) {
					System.out.println(index + ". " + roomType.getName() + " Room Type: " + availableRooms + " rooms available.");
					index++;
					hasAvailableRooms = true;
				} else {
					System.out.println(index + ". " + roomType.getName() + " Room Type has no rooms available.");
				}
			}

			// Prompt for reservation if rooms are available
			if (hasAvailableRooms) {
				System.out.print("\nWould you like to make a reservation? (y/n): ");
				String response = scanner.nextLine().trim();

				if (response.equalsIgnoreCase("y")) {
					handleReservationSelection(scanner, roomTypes, checkInDate, checkOutDate, index);
				} else {
					System.out.println("Reservation canceled.");
				}
			} else {
				System.out.println("No rooms available for the selected dates.");
			}

		} catch (ParseException ex) {
			System.out.println("Invalid Date Input.");
		}
	}

	private void handleReservationSelection(Scanner scanner, List<RoomType> roomTypes, Date checkInDate, Date checkOutDate, int index) {
		Map<RoomType, Integer> roomTypesToReserve = new HashMap<>();

		while (true) {
			System.out.print("\nEnter the corresponding number of the room type to reserve (or 0 to finish selection): ");
			int selectedRoomTypeNumber = Integer.parseInt(scanner.nextLine().trim());

			// Exit if user selects 0
			if (selectedRoomTypeNumber == 0) {
				break;
			}

			if (selectedRoomTypeNumber >= 1 && selectedRoomTypeNumber < index) {
				RoomType selectedRoomType = roomTypes.get(selectedRoomTypeNumber - 1);

				// Calculate available rooms for the selected room type using the updated logic
				int availableRooms = selectedRoomType.getRooms().size();
				for (Room room : selectedRoomType.getRooms()) {
					if (room.getStatus().equals(StatusEnum.DISABLED)) {
						availableRooms--;
					}
				}

				List<ReservationDetail> reservations = reservationControllerSessionBeanRemote.retrieveReservationDetailsByRoomTypeAndDate(selectedRoomType, checkInDate, checkOutDate);
				for (ReservationDetail reservationDetail : reservations) {
					availableRooms -= reservationDetail.getNumOfRooms();
				}

				System.out.println("Available rooms for " + selectedRoomType.getName() + ": " + availableRooms);
				System.out.print("Enter the number of rooms to reserve for " + selectedRoomType.getName() + "> ");
				int numRoomsToReserve = Integer.parseInt(scanner.nextLine().trim());

				if (numRoomsToReserve <= availableRooms) {
					roomTypesToReserve.put(selectedRoomType, numRoomsToReserve);
					System.out.println(numRoomsToReserve + " rooms added for " + selectedRoomType.getName() + ".");
				} else {
					System.out.println("Not enough rooms available in " + selectedRoomType.getName() + ". Available: " + availableRooms);
				}
			} else {
				System.out.println("Invalid selection. Please enter a valid number.");
			}
		}

		if (!roomTypesToReserve.isEmpty()) {
			Long reservationID = doReserveRoom(checkInDate, checkOutDate, roomTypesToReserve);
			if (reservationID != null) {
				System.out.println("Reservation successful for the selected room types. Your Reservation ID is: " + reservationID);
			} else {
				System.out.println("Reservation process cancelled.");
			}
		} else {
			System.out.println("No valid room types were selected. Reservation canceled.");
		}
	}

	public Long doReserveRoom(Date checkInDate, Date checkOutDate, Map<RoomType, Integer> numRoomTypesToReserve) {
		try {
			WalkInReservation newWalkInReservation = new WalkInReservation();
			newWalkInReservation.setStartDate(checkInDate);
			newWalkInReservation.setEndDate(checkOutDate);
			newWalkInReservation.setEmployee(currentEmployee);

			BigDecimal totalAmount = BigDecimal.ZERO;

			// Loop through each RoomType to reserve rooms
			for (Map.Entry<RoomType, Integer> entry : numRoomTypesToReserve.entrySet()) {
				RoomType roomType = entry.getKey();
				int numRoomsToReserve = entry.getValue();

				ReservationDetail reservationDetail = new ReservationDetail();
				reservationDetail.setNumOfRooms(numRoomsToReserve);
				reservationDetail.setRoomType(roomType);
				newWalkInReservation.getReservationDetails().add(reservationDetail);

				BigDecimal amountForRoomType = walkInReservationSessionBeanRemote.calculateAmount(roomType, numRoomsToReserve, checkInDate, checkOutDate);
				totalAmount = totalAmount.add(amountForRoomType);
			}

			newWalkInReservation.setReservationFee(totalAmount);

			System.out.println("The total reservation fee is: " + totalAmount);
			System.out.print("Do you want to proceed with the reservation? (y/n): ");
			Scanner scanner = new Scanner(System.in);
			String confirmation = scanner.nextLine().trim();

			if (confirmation.equalsIgnoreCase("y")) {
				WalkInReservation persistedReservation = reservationControllerSessionBeanRemote.createNewWalkInReservation(currentEmployee.getEmployeeId(), newWalkInReservation);
				System.out.println("Reservation successful. Reservation ID: " + persistedReservation.getReservationId());
				return persistedReservation.getReservationId();
			} else {
				System.out.println("Reservation canceled by the user.");
				return null;
			}

		} catch (Exception e) {
			System.out.println("Failed to create reservation: " + e.getMessage());
			return null;
		}
	}

	public void doCheckin() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("*** Hotel Reservation System (HoRS) :: Front Office :: Check In ***\n");
		Date today = new Date();
		try {
			List<Reservation> reservations = reservationControllerSessionBeanRemote.retrieveReservationsByCheckInDate(today);
			if (reservations.isEmpty()) {
				System.out.println("No reservations found for today.");
				return;
			}

			System.out.println("Reservations Due For Check In Today:");
			for (int i = 0; i < reservations.size(); i++) {
				System.out.println((i + 1) + ": Reservation ID " + reservations.get(i).getReservationId());
			}

			System.out.print("Enter the corresponding number of the reservation to check in: ");
			int choice = scanner.nextInt();

			if (choice < 1 || choice > reservations.size()) {
				System.out.println("Invalid choice. Please try again.");
				return;
			}

			// Retrieve the selected reservation
			Reservation selectedReservation = reservations.get(choice - 1);
			System.out.println("You selected Reservation ID " + selectedReservation.getReservationId() + " for check-in.");

			List<AllocationReport> allAllocationReports = new ArrayList<>();

			for (ReservationDetail reservationDetail : selectedReservation.getReservationDetails()) {
				List<AllocationReport> allocationReports = roomAllocationSessionBeanRemote.retrieveAllocationReportByReservationDetailId(reservationDetail.getReservationDetailId());
				allAllocationReports.addAll(allocationReports);
			}

			// Display Allocated Room(s) for reservation
			System.out.println("These are your allocated rooms for your reservation: ");
			for (AllocationReport a : allAllocationReports) {
				for (ReservationDetail reservationDetail : a.getReservationDetail()) {
					RoomType roomType = reservationDetail.getRoomType();
					Integer numOfRooms = reservationDetail.getNumOfRooms();
					Integer roomNumber = a.getRoomNumber();

					System.out.println("Room Type: " + roomType.getName());
					System.out.println("Number of Rooms: " + numOfRooms);
					System.out.println("Room Number: " + roomNumber);
					System.out.println("--------------------");
				}
			}

		} catch (AllocationReportNotFoundException ex) {
			System.out.println(ex.getMessage());
		}
	}

	public void doCheckout() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("*** Hotel Reservation System (HoRS) :: Front Office :: Check Out ***\n");
		Date today = new Date();
		try {
			List<Reservation> reservations = reservationControllerSessionBeanRemote.retrieveReservationsByCheckOutDate(today);
			if (reservations.isEmpty()) {
				System.out.println("No reservations found for today.");
				return;
			}
			
			System.out.println("Reservations Due For Check Out Today:");
			for (int i = 0; i < reservations.size(); i++) {
				System.out.println((i + 1) + ": Reservation ID " + reservations.get(i).getReservationId());
			}

			System.out.print("Enter the corresponding number of the reservation to check out: ");
			int choice = scanner.nextInt();

			if (choice < 1 || choice > reservations.size()) {
				System.out.println("Invalid choice. Please try again.");
				return;
			}
			
			Reservation selectedReservation = reservations.get(choice - 1);
			System.out.println("You selected Reservation ID " + selectedReservation.getReservationId() + " for check-out.");
			
			List<AllocationReport> allAllocationReports = new ArrayList<>();

			for (ReservationDetail reservationDetail : selectedReservation.getReservationDetails()) {
				List<AllocationReport> allocationReports = roomAllocationSessionBeanRemote.retrieveAllocationReportByReservationDetailId(reservationDetail.getReservationDetailId());
				allAllocationReports.addAll(allocationReports);
			}

			// Update the allocation status to NOT_ALLOCATED for each allocation report
			for (AllocationReport allocationReport : allAllocationReports) {
				allocationReport.setAllocationStatus(AllocationStatusEnum.NOT_ALLOCATED);
				roomAllocationSessionBeanRemote.updateAllocationStatus(allocationReport);
				System.out.println("Room " + allocationReport.getRoomNumber() + " has been checked out");
			}
			
			System.out.println("Check-out process completed successfully for Reservation ID " + selectedReservation.getReservationId() + ".");

		} catch (NoResultException | AllocationReportNotFoundException ex) {
			System.out.println(ex.getMessage());
		}
	}
}
