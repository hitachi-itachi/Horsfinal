package ejb.session.stateless;

import entity.RoomType;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import util.enumeration.RateTypeEnum;
import util.enumeration.StatusEnum;

@Stateless
public class WalkInReservationSessionBean implements WalkInReservationSessionBeanRemote, WalkInReservationSessionBeanLocal {

	@PersistenceContext(unitName = "HoRS-ejbPU")
	private EntityManager em;

	public WalkInReservationSessionBean() {
	}

	@Override
	public BigDecimal calculateAmount(RoomType roomType, int numRoomsToReserve, Date checkInDate, Date checkOutDate) {
		BigDecimal nightlyRate = chooseRoomRate(roomType); // Fetch the room rate for the RoomType
		long numNights = calculateNumNights(checkInDate, checkOutDate); // Calculate the number of nights based on check-in and check-out dates
		return nightlyRate.multiply(BigDecimal.valueOf(numRoomsToReserve)).multiply(BigDecimal.valueOf(numNights));
	}

	private BigDecimal chooseRoomRate(RoomType roomType) {
		Query query = em.createQuery(
				"SELECT rr.ratePerNight FROM RoomRate rr WHERE rr.roomType = :roomType AND rr.rateType = :rateType AND rr.status = :status");
		query.setParameter("roomType", roomType);
		query.setParameter("rateType", RateTypeEnum.PUBLISHED);
		query.setParameter("status", StatusEnum.AVAILABLE);

		List<BigDecimal> results = query.getResultList();
		if (results.isEmpty()) {
			throw new IllegalArgumentException("Active published rate not found for RoomType: " + roomType.getName());
		} else if (results.size() > 1) {
			// Handle multiple rates scenario appropriately, for now pick the first entry (can have two published rates that are active)
			System.out.println("Warning: Multiple active published rates found for RoomType: " + roomType.getName());
			return results.get(0);
		} else {
			return results.get(0);
		}
	}

	private long calculateNumNights(Date checkInDate, Date checkOutDate) {
		long diffInMillies = Math.abs(checkOutDate.getTime() - checkInDate.getTime());
		return diffInMillies / (24 * 60 * 60 * 1000);
	}
}
