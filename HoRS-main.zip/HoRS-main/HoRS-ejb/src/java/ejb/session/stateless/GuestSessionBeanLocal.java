package ejb.session.stateless;

import entity.Guest;
import javax.ejb.Local;
import util.exception.GuestEmailExistException;
import util.exception.GuestNotFoundException;
import util.exception.InputDataValidationException;
import util.exception.InvalidLoginCredentialException;
import util.exception.UnknownPersistenceException;

@Local
public interface GuestSessionBeanLocal {

	public Long registerNewGuest(Guest newGuestEntity) throws GuestEmailExistException, UnknownPersistenceException, InputDataValidationException;

	public Guest guestLogin(String email, String password) throws InvalidLoginCredentialException;

	public Guest retrieveGuestByEmail(String email) throws GuestNotFoundException;

	public Guest retrieveGuestById(Long guestId) throws GuestNotFoundException;

}
