package ejb.session.stateless;

import entity.AllocationReport;
import entity.ReservationDetail;
import entity.Room;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.ws.rs.NotFoundException;
import util.enumeration.AllocationStatusEnum;
import util.exception.AllocationReportNotFoundException;
import util.exception.CreateNewReportException;
import util.exception.RoomNotFoundException;

@Stateless
public class RoomAllocationSessionBean implements RoomAllocationSessionBeanRemote, RoomAllocationSessionBeanLocal {

	@PersistenceContext(unitName = "HoRS-ejbPU")
	private EntityManager em;

	@Override
	public AllocationReport createNewAllocationRecord(ReservationDetail reservationDetail, AllocationReport allocationReport) throws CreateNewReportException {
		try {
			allocationReport.getReservationDetail().add(reservationDetail);
			em.persist(allocationReport);
			em.flush();
			return allocationReport;

		} catch (PersistenceException ex) {
			ex.printStackTrace();
			throw new CreateNewReportException("An error occurred while creating the Allocation Report: " + ex.getMessage());
		}
	}

	@Override
	public List<ReservationDetail> retrieveReservationDetailByDate(Date checkedInDate) throws AllocationReportNotFoundException {
		try {
			// Query to find all AllocationReports with the specified date (ignoring time)
			Query query = em.createQuery(
					"SELECT a FROM AllocationReport a WHERE a.checkInDate = :checkedInDate", AllocationReport.class);
			query.setParameter("checkedInDate", checkedInDate);

			// Get list of all matching AllocationReports
			List<AllocationReport> reports = query.getResultList();

			// Combine ReservationDetails from all AllocationReports into a single list
			List<ReservationDetail> allReservationDetails = new ArrayList<>();
			for (AllocationReport report : reports) {
				report.getReservationDetail().size();  
				allReservationDetails.addAll(report.getReservationDetail());
			}

			return allReservationDetails;

		} catch (NoResultException e) {
			throw new AllocationReportNotFoundException("Allocation report not found for the specified date.");
		}
	}

	@Override
	public void updateReservationDetailsInAllocation(Date checkedInDate, ReservationDetail newReservationDetail) throws AllocationReportNotFoundException {
		try {
			Query query = em.createQuery(
					"SELECT a FROM AllocationReport a WHERE DATE(a.checkInDate) = :checkedInDate", AllocationReport.class);
			query.setParameter("checkedInDate", checkedInDate);
			AllocationReport report = (AllocationReport) query.getSingleResult();
			report.getReservationDetail().size();

			// Update the reservation details list with the new detail
			report.getReservationDetail().add(newReservationDetail);

			// Merge the updated report back into persistence context
			em.merge(report);
		} catch (NoResultException e) {
			throw new AllocationReportNotFoundException("Allocation report not found for the specified date.");
		}
	}

//	@Override
//	public List<Integer> retrieveAListOfAllocatedRoomsNumber() throws RoomNotFoundException {
//		try {
//			Query query = em.createQuery("SELECT a.roomNumber FROM AllocationReport a");
//			query.getResultList().size();
//			return query.getResultList();
//		} catch (NotFoundException ex) {
//			throw new RoomNotFoundException("No allocated Room not found");
//		}
//	}
	@Override
	public List<Integer> retrieveAListOfAllocatedRoomsNumber() throws RoomNotFoundException {
		try {
			Query query = em.createQuery("SELECT a.roomNumber FROM AllocationReport a WHERE a.allocationStatus = :status");
			query.setParameter("status", AllocationStatusEnum.ALLOCATED);
			List<Integer> allocatedRoomNumbers = query.getResultList();

			if (allocatedRoomNumbers.isEmpty()) {
				throw new RoomNotFoundException("No allocated rooms found.");
			}

			return allocatedRoomNumbers;
		} catch (NoResultException ex) {
			throw new RoomNotFoundException("No allocated rooms found.");
		}
	}

	@Override
	public List<AllocationReport> retrieveAListOfUpgradedReservation() throws RoomNotFoundException {
		try {
			Query query = em.createQuery("SELECT a FROM AllocationReport a WHERE a.allocationStatus = :allocatedStatus");
			query.setParameter("allocatedStatus", AllocationStatusEnum.UPGRADED);
			List<AllocationReport> allocationReports = query.getResultList();
			for (AllocationReport allocationReport : allocationReports) {
				allocationReport.getReservationDetail().size();
			}

			return query.getResultList();
		} catch (NotFoundException ex) {
			throw new RoomNotFoundException("No upgraded record found");
		}
	}

	@Override
	public List<AllocationReport> retrieveAListOfNotUpgradedReservation() throws RoomNotFoundException {
		try {
			Query query = em.createQuery("SELECT a FROM AllocationReport a WHERE a.allocationStatus= :allocatedStatus");
			query.setParameter("allocatedStatus", AllocationStatusEnum.NOT_UPGRADED);
			List<AllocationReport> allocationReports = query.getResultList();
			for (AllocationReport allocationReport : allocationReports) {
				allocationReport.getReservationDetail().size();
			}
			return query.getResultList();
		} catch (NotFoundException ex) {
			throw new RoomNotFoundException("No not upgraded record found");
		}
	}

	@Override
	public List<AllocationReport> retrieveAllocationReportByReservationDetailId(Long reservationDetailId) throws AllocationReportNotFoundException {
		Query query = em.createQuery(
				"SELECT a FROM AllocationReport a JOIN a.reservationDetail rd WHERE rd.reservationDetailId = :reservationDetailId");
		query.setParameter("reservationDetailId", reservationDetailId);

		List<AllocationReport> allocationReports = query.getResultList();
		
		for (AllocationReport allocationReport : allocationReports) {
			allocationReport.getReservationDetail().size();
		}

		if (allocationReports.isEmpty()) {
			throw new AllocationReportNotFoundException("No Allocation Report found for ReservationDetail ID " + reservationDetailId);
		}

		return allocationReports; 
	}
	
	@Override
	public void updateAllocationStatus(AllocationReport allocationReport) {
		if (allocationReport != null) {
			AllocationReport managedReport = em.merge(allocationReport); 
			managedReport.setAllocationStatus(AllocationStatusEnum.NOT_ALLOCATED); 
			em.flush(); 
		}
	}

}
