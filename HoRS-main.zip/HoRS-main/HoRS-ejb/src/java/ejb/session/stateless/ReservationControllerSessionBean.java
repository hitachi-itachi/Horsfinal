package ejb.session.stateless;

import entity.AllocationReport;
import entity.Employee;
import entity.Guest;
import entity.OnlineReservation;
import entity.PartnerEmployee;
import entity.PartnerReservation;
import entity.Reservation;
import entity.ReservationDetail;
import entity.RoomType;
import entity.WalkInReservation;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import util.exception.AllocationReportNotFoundException;
import util.exception.CreateNewOnlineReservationException;
import util.exception.CreateNewPartnerReservationException;
import util.exception.CreateNewWalkInReservationException;
import util.exception.EmployeeNotFoundException;
import util.exception.GuestNotFoundException;
import util.exception.PartnerNotFoundException;
import util.exception.ReservationDetailNotFoundException;
import util.exception.ReservationNotFoundException;

@Stateless
public class ReservationControllerSessionBean implements ReservationControllerSessionBeanRemote, ReservationControllerSessionBeanLocal {

	@PersistenceContext(unitName = "HoRS-ejbPU")
	private EntityManager em;

	@EJB
	private EmployeeSessionBeanLocal employeeSessionBeanLocal;

	@EJB
	private GuestSessionBeanLocal guestSessionBeanLocal;

	@EJB
	private PartnerEmployeeSessionBeanLocal partnerEmployeeSessionBeanLocal;

	@EJB
	private SchedulerSessionBeanLocal schedulerSessionBeanLocal;

	public ReservationControllerSessionBean() {
	}

	@Override
	public List<ReservationDetail> retrieveReservationDetailsByRoomTypeAndDate(RoomType roomType, Date checkInDate, Date checkOutDate) {
		Query query = em.createQuery(
				"SELECT rd FROM Reservation r JOIN r.reservationDetails rd "
				+ "WHERE rd.roomType = :roomType "
				+ "AND (r.startDate < :checkOutDate AND r.endDate > :checkInDate)"
		);
		query.setParameter("roomType", roomType);
		query.setParameter("checkInDate", checkInDate);
		query.setParameter("checkOutDate", checkOutDate);

		return query.getResultList();
	}

	@Override
	public List<ReservationDetail> retrieveReservationDetailsByDate(Date checkInDate) {

		// Create the query to find reservations that include the check-in date
		Query query = em.createQuery("SELECT r.reservationDetails FROM Reservation r WHERE r.startDate = :checkInDate");
		query.setParameter("checkInDate", checkInDate);
		query.getResultList().size();

		return query.getResultList();
	}

	@Override
	public WalkInReservation createNewWalkInReservation(Long employeeId, WalkInReservation newWalkInReservation) throws EmployeeNotFoundException, CreateNewWalkInReservationException {
		if (newWalkInReservation != null) {
			try {
				Employee employee = employeeSessionBeanLocal.retrieveEmployeeById(employeeId);
				newWalkInReservation.setEmployee(employee);
				employee.getWalkInReservations().add(newWalkInReservation);
				
				em.persist(newWalkInReservation);
				em.flush();

				Date checkInDate = newWalkInReservation.getStartDate();
				Date today = new Date();
				System.out.println(today);

				if (isSameDay(checkInDate, today)) {
					System.out.println("Same-day reservation detected. Allocating room immediately." + "Today's date is: +" + today);

					for (ReservationDetail detail : newWalkInReservation.getReservationDetails()) {
						RoomType roomType = detail.getRoomType();
						Integer numOfRooms = detail.getNumOfRooms();
						if (roomType != null) {
							schedulerSessionBeanLocal.roomAllocationSameDay(numOfRooms, roomType.getRoomTypeId(), detail, checkInDate);
						}
					}
				}
			
				return newWalkInReservation;
			} catch (EmployeeNotFoundException ex) {

				throw new CreateNewWalkInReservationException(ex.getMessage());
			}
		} else {
			throw new CreateNewWalkInReservationException("Walk In Reservation Information Not Provided");
		}
	}

	@Override
	public OnlineReservation createNewOnlineReservation(Long guestId, OnlineReservation newOnlineReservation) throws GuestNotFoundException, CreateNewOnlineReservationException {
		if (newOnlineReservation != null) {
			try {
				Guest guest = guestSessionBeanLocal.retrieveGuestById(guestId);
				newOnlineReservation.setGuest(guest);
				guest.getOnlineReservations().add(newOnlineReservation);

				em.persist(newOnlineReservation);
				em.flush();
				
				Date checkInDate = newOnlineReservation.getStartDate();
				Date today = new Date();
				System.out.println(today);

				if (isSameDay(checkInDate, today)) {
					System.out.println("Same-day reservation detected. Allocating room immediately." + "Today's date is: +" + today);

					for (ReservationDetail detail : newOnlineReservation.getReservationDetails()) {
						RoomType roomType = detail.getRoomType();
						Integer numOfRooms = detail.getNumOfRooms();
						if (roomType != null) {
							schedulerSessionBeanLocal.roomAllocationSameDay(numOfRooms, roomType.getRoomTypeId(), detail, checkInDate);
						}
					}
				}

				return newOnlineReservation;
			} catch (GuestNotFoundException ex) {

				throw new CreateNewOnlineReservationException(ex.getMessage());
			}
		} else {
			throw new CreateNewOnlineReservationException("Online Reservation Information Not Provided");
		}
	}

	@Override
	public PartnerReservation createNewPartnerReservation(Long partnerId, PartnerReservation newPartnerReservation) throws PartnerNotFoundException, CreateNewPartnerReservationException {
		if (newPartnerReservation != null) {
			try {
				PartnerEmployee partnerEmployee = partnerEmployeeSessionBeanLocal.retrievePartnerById(partnerId);
				newPartnerReservation.setPartnerEmployee(partnerEmployee);
				partnerEmployee.getPartnerReservations().add(newPartnerReservation);

				em.persist(newPartnerReservation);
				em.flush();
				
				Date checkInDate = newPartnerReservation.getStartDate();
				Date today = new Date();
				System.out.println(today);

				if (isSameDay(checkInDate, today)) {
					System.out.println("Same-day reservation detected. Allocating room immediately." + "Today's date is: +" + today);

					for (ReservationDetail detail : newPartnerReservation.getReservationDetails()) {
						RoomType roomType = detail.getRoomType();
						Integer numOfRooms = detail.getNumOfRooms();
						if (roomType != null) {
							schedulerSessionBeanLocal.roomAllocationSameDay(numOfRooms, roomType.getRoomTypeId(), detail, checkInDate);
						}
					}
				}

				return newPartnerReservation;
			} catch (PartnerNotFoundException ex) {

				throw new CreateNewPartnerReservationException(ex.getMessage());
			}
		} else {
			throw new CreateNewPartnerReservationException("Online Reservation Information Not Provided");
		}
	}

	@Override
	public ReservationDetail retrieveReservationDetailById(Long reservationDetailId) throws ReservationDetailNotFoundException {
		ReservationDetail reservationDetail = em.find(ReservationDetail.class, reservationDetailId);

		if (reservationDetail != null) {
			return reservationDetail;
		} else {
			throw new ReservationDetailNotFoundException("reservationDetail ID " + reservationDetailId + " does not exist!");
		}
	}

	@Override
	public Reservation retrieveReservationById(Long reservationId) throws ReservationNotFoundException {
		Reservation reservation = em.find(Reservation.class, reservationId);

		if (reservation != null) {
			reservation.getReservationDetails().size();
			return reservation;
		} else {
			throw new ReservationNotFoundException("Reservation ID " + reservationId + " does not exist!");
		}
	}

	@Override
	public List<Reservation> retrieveOnlineReservationsByGuestId(Long guestId) {
		Query query = em.createQuery("SELECT o FROM OnlineReservation o WHERE o.guest.guestId = :inGuest");
		query.setParameter("inGuest", guestId);
		List<Reservation> reservations = query.getResultList();

		for (Reservation reservation : reservations) {
			// Manual fetch
			reservation.getReservationDetails().size();
		}

		return reservations;

	}

	@Override
	public List<Reservation> retrievePartnerReservationsByPartnerId(Long partnerId) {
		Query query = em.createQuery("SELECT p FROM PartnerReservation p WHERE p.partnerEmployee.partnerEmployeeId = :inPartner");
		query.setParameter("inPartner", partnerId);
		List<Reservation> reservations = query.getResultList();

		for (Reservation reservation : reservations) {
			reservation.getReservationDetails().size();
		}

		return reservations;

	}

	@Override
	public List<Reservation> retrieveReservationsByCheckInDate(Date checkinDate) throws NoResultException {
		try {
			Query query = em.createQuery(
					"SELECT r FROM Reservation r WHERE r.startDate = :checkedInDate");
			query.setParameter("checkedInDate", checkinDate);

			List<Reservation> reservations = query.getResultList();

			for (Reservation reservation : reservations) {
				reservation.getReservationDetails().size();
			}

			return reservations;

		} catch (NoResultException e) {
			throw new NoResultException("Reservations not found for the specified date.");
		}
	}
	
	@Override
	public List<Reservation> retrieveReservationsByCheckOutDate(Date checkoutDate) throws NoResultException {
		try {
			Query query = em.createQuery(
					"SELECT r FROM Reservation r WHERE r.endDate = :checkedOutDate");
			query.setParameter("checkedOutDate", checkoutDate);

			List<Reservation> reservations = query.getResultList();

			for (Reservation reservation : reservations) {
				reservation.getReservationDetails().size();
			}

			return reservations;

		} catch (NoResultException e) {
			throw new NoResultException("Reservations not found for the specified date.");
		}
	}

	private boolean isSameDay(Date date1, Date date2) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		return sdf.format(date1).equals(sdf.format(date2));
	}

}
