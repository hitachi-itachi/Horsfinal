package ejb.session.stateless;

import entity.RoomType;
import java.math.BigDecimal;
import java.util.Date;
import javax.ejb.Local;


@Local
public interface OnlineReservationSessionBeanLocal {

	public BigDecimal calculateAmount(RoomType roomType, int numRoomsToReserve, Date checkInDate, Date checkOutDate);
	
}
