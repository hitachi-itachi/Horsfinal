package ejb.session.stateless;

import entity.Room;
import entity.RoomRate;
import entity.RoomType;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import util.enumeration.StatusEnum;
import util.exception.CreateNewRoomException;
import util.exception.CreateNewRoomRateException;
import util.exception.DeleteRoomException;
import util.exception.DeleteRoomRateException;

import util.exception.DeleteRoomTypeException;
import util.exception.DuplicateRoomTypeException;
import util.exception.RoomTypeNotFoundException;
import util.exception.UnknownPersistenceException;
import util.exception.UpdateRoomTypeException;
import util.exception.DuplicateRoomException;
import util.exception.DuplicateRoomRateException;
import util.exception.EntityInstanceExistsInCollectionException;
import util.exception.EntityInstanceMissingInCollectionException;
import util.exception.RoomNotFoundException;
import util.exception.RoomRateNotFoundException;
import util.exception.UpdateRoomException;
import util.exception.UpdateRoomRateException;

@Stateless
public class RoomManagementSessionBean implements RoomManagementSessionBeanRemote, RoomManagementSessionBeanLocal {

	@PersistenceContext(unitName = "HoRS-ejbPU")
	private EntityManager em;

	public RoomManagementSessionBean() {
	}

	@Override
	public long createNewRoomType(RoomType newRoomType) throws DuplicateRoomTypeException, UnknownPersistenceException {
		if (newRoomType == null) {
			throw new IllegalArgumentException("Room type cannot be null.");
		}

		try {
			Query query = em.createQuery("SELECT rt FROM RoomType rt WHERE rt.name = :name");
			query.setParameter("name", newRoomType.getName());

			List<RoomType> existingRoomTypes = query.getResultList();

			if (!existingRoomTypes.isEmpty()) {
				throw new DuplicateRoomTypeException("Room type with the name '" + newRoomType.getName() + "' already exists.");
			}

			em.persist(newRoomType);
			em.flush();

			return newRoomType.getRoomTypeId();
		} catch (PersistenceException ex) {
			throw new UnknownPersistenceException(ex.getMessage());
		}
	}

	@Override
	public RoomType retrieveRoomType(Long roomTypeId) throws RoomTypeNotFoundException {
		RoomType roomType = em.find(RoomType.class, roomTypeId);
		roomType.getRooms().size();
		// Check if the room type exists
		if (roomType == null) {
			throw new RoomTypeNotFoundException("Room Type ID " + roomTypeId + " does not exist!");
		}

		return roomType;
	}

	@Override
	public List<RoomType> retrieveAllRoomTypes() {
		Query query = em.createQuery("SELECT rt FROM RoomType rt");
		List<RoomType> result = query.getResultList();
		for (RoomType roomType : result) {
			// Trigger Manual lazy fetch
			roomType.getRooms().size();
			roomType.getRoomRates().size();
		}

		System.out.println("Retrieved Room Types: " + result.size());
		return result;
	}

	@Override
	public List<Room> retrieveRoomsByRank(Integer ranking) throws RoomTypeNotFoundException {

		try {
			Query query = em.createQuery("SELECT r FROM RoomType r WHERE r.ranking = :rank");
			query.setParameter("rank", ranking);
			RoomType roomType = (RoomType) query.getSingleResult();
			roomType.getRooms().size();

			// Initialize the room list (if necessary)
			//roomType.getRooms().size(); // This line forces the collection to be loaded if lazy-loaded
			return roomType.getRooms();
		} catch (NoResultException ex) {
			throw new RoomTypeNotFoundException("Room Type ranking " + ranking + " does not exist!");
		}
	}

	@Override
	public void updateRoomType(RoomType roomType) throws RoomTypeNotFoundException, UpdateRoomTypeException {
		if (roomType != null && roomType.getRoomTypeId() != null) {
			RoomType roomTypeToUpdate = retrieveRoomType(roomType.getRoomTypeId());

			roomTypeToUpdate.setName(roomType.getName());
			roomTypeToUpdate.setDescription(roomType.getDescription());
			roomTypeToUpdate.setRoomSize(roomType.getRoomSize());
			roomTypeToUpdate.setBed(roomType.getBed());
			roomTypeToUpdate.setCapacity(roomType.getCapacity());
			roomTypeToUpdate.setAmenities(roomType.getAmenities());
			roomTypeToUpdate.setStatus(roomType.getStatus());
			roomTypeToUpdate.setRanking(roomType.getRanking());

			em.merge(roomTypeToUpdate);
			em.flush();
		} else {
			throw new RoomTypeNotFoundException("Room type ID not provided for room type to be updated");
		}
	}

	@Override
	public void deleteRoomType(Long roomTypeId) throws RoomTypeNotFoundException, DeleteRoomTypeException {
		RoomType roomTypeToRemove = retrieveRoomType(roomTypeId);

		if (roomTypeToRemove == null) {
			throw new RoomTypeNotFoundException("Room Type ID " + roomTypeId + " does not exist!");
		}

		Query query = em.createQuery("SELECT r FROM Room r WHERE r.roomType = :roomType AND r.status = :activeStatus");
		query.setParameter("roomType", roomTypeToRemove);
		query.setParameter("activeStatus", StatusEnum.AVAILABLE);

		// If there are active rooms (used), mark as disabled
		if (!query.getResultList().isEmpty()) {
			roomTypeToRemove.setStatus(StatusEnum.DISABLED);
			em.merge(roomTypeToRemove);
			throw new DeleteRoomTypeException("Room Type is currently in use and has been marked as DISABLED.");
		} else {
			// If the room type is not used by any rooms, proceed with deletion
			em.remove(roomTypeToRemove);
		}
	}

	@Override
	public long createNewRoom(Long roomTypeId, Room newRoom) throws RoomTypeNotFoundException, CreateNewRoomException, DuplicateRoomException {
		if (newRoom != null) {
			try {
				RoomType roomType = retrieveRoomType(roomTypeId);
				
				if (roomType.getRooms().size() >= roomType.getCapacity()) {
					throw new CreateNewRoomException("Cannot create a new room: RoomType '" + roomType.getName() + "' has reached its capacity.");
				}

				Query query = em.createQuery("SELECT r FROM Room r WHERE r.roomNumber = :roomNumber");
				query.setParameter("roomNumber", newRoom.getRoomNumber());
				List<Room> existingRooms = query.getResultList();

				if (!existingRooms.isEmpty()) {
					throw new DuplicateRoomException("Room with number '" + newRoom.getRoomNumber() + "' already exists. Please try again.");
				}

				newRoom.setRoomType(roomType);
				roomType.getRooms().add(newRoom);

				em.persist(newRoom);
				em.flush();

				return newRoom.getRoomId();

			} catch (RoomTypeNotFoundException ex) {
				throw new RoomTypeNotFoundException("An error occurred while creating the room: " + ex.getMessage());
			}
		} else {
			throw new CreateNewRoomException("Room information not provided.");
		}
	}

	@Override
	public Room retrieveRoomById(Long roomId) throws RoomNotFoundException {
		try {
			Query query = em.createQuery("SELECT r FROM Room r WHERE r.roomId = :roomId");
			query.setParameter("roomId", roomId);
			Room room = (Room) query.getSingleResult();
			
			room.getRoomType();
			return room;

		} catch (NoResultException ex) {
			throw new RoomNotFoundException("Room with ID " + roomId + " does not exist.");
		}
	}
	
	@Override
	public Room retrieveRoom(int roomNumber) throws RoomNotFoundException {
		try {
			Query query = em.createQuery("SELECT r FROM Room r WHERE r.roomNumber = :roomNumber");
			query.setParameter("roomNumber", roomNumber);
			Room room = (Room) query.getSingleResult();
			
			room.getRoomType();
			return room;

		} catch (NoResultException ex) {
			throw new RoomNotFoundException("Room Number " + roomNumber + " does not exist.");
		}
	}

	@Override
	public List<Room> retrieveAllRooms() {
		Query query = em.createQuery("SELECT r FROM Room r");
		List<Room> result = query.getResultList();
		System.out.println("Retrieved Rooms: " + result.size());
		return result;
	}

	@Override
	public void updateRoom(Room room) throws RoomNotFoundException, UpdateRoomException {
		if (room != null && room.getRoomId() != null) {
			Room roomToUpdate = retrieveRoomById(room.getRoomId());

			roomToUpdate.setRoomNumber(room.getRoomNumber());
			roomToUpdate.setRoomType(room.getRoomType());
			roomToUpdate.setStatus(room.getStatus());

			em.merge(roomToUpdate);
			em.flush();
		} else {
			throw new RoomNotFoundException("Room ID not provided for room to be updated");
		}
	}

	@Override
	public void deleteRoom(int roomNumber) throws RoomNotFoundException, DeleteRoomException {
		Room roomToDelete = retrieveRoom(roomNumber);

		if (roomToDelete == null) {
			throw new RoomNotFoundException("Room  " + roomNumber + " does not exist!");
		}

		if (roomToDelete.getStatus().equals(StatusEnum.DISABLED)) {
			RoomType roomType = roomToDelete.getRoomType();
			if (roomType != null) {
				try {
					roomType.removeRoom(roomToDelete);
				} catch (EntityInstanceMissingInCollectionException ex) {
					System.out.println(ex.getMessage());
				}
			}
			em.remove(roomToDelete);

		} else {
			roomToDelete.setStatus(StatusEnum.DISABLED);
			em.merge(roomToDelete);
			throw new DeleteRoomException("Room is currently in use and has been marked as DISABLED.");
		}
	}

	@Override
	public long createNewRoomRate(Long roomTypeId, RoomRate newRoomRate) throws RoomTypeNotFoundException, CreateNewRoomRateException, DuplicateRoomRateException {
		if (newRoomRate != null) {
			try {
				// Retrieve the RoomType to associate with the RoomRate
				RoomType roomType = retrieveRoomType(roomTypeId);

				// Check for duplicate RoomRate with the same name under the same RoomType
				Query query = em.createQuery("SELECT rr FROM RoomRate rr WHERE rr.name = :name AND rr.roomType = :roomType");
				query.setParameter("name", newRoomRate.getName());
				query.setParameter("roomType", roomType);
				List<RoomRate> existingRoomRates = query.getResultList();

				if (!existingRoomRates.isEmpty()) {
					throw new DuplicateRoomRateException("RoomRate with name '" + newRoomRate.getName() + "' already exists for this RoomType. Please try again.");
				}

				// Associate the RoomRate with the RoomType
				newRoomRate.setRoomType(roomType);
				roomType.getRoomRates().add(newRoomRate);

				// Persist the RoomRate entity
				em.persist(newRoomRate);
				em.flush();

				return newRoomRate.getRoomRateId();

			} catch (RoomTypeNotFoundException ex) {
				throw new RoomTypeNotFoundException("An error occurred while creating the RoomRate: " + ex.getMessage());
			}
		} else {
			throw new CreateNewRoomRateException("RoomRate information not provided.");
		}
	}

	public List<RoomRate> retrieveAllRoomRates() {
		Query query = em.createQuery("SELECT rr FROM RoomRate rr");
		List<RoomRate> result = query.getResultList();
		System.out.println("Retrieved Room Rate: " + result.size());
		return result;
	}

	@Override
	public RoomRate retrieveRoomRate(Long roomRateId) throws RoomRateNotFoundException {
		RoomRate roomRate = em.find(RoomRate.class, roomRateId);
		// Check if the room type exists
		if (roomRate == null) {
			throw new RoomRateNotFoundException("Room Type ID " + roomRateId + " does not exist!");
		}

		return roomRate;
	}

	@Override
	public void updateRoomRate(RoomRate roomRate) throws RoomRateNotFoundException, UpdateRoomRateException {
		if (roomRate != null && roomRate.getRoomRateId() != null) {
			RoomRate roomRateToUpdate = retrieveRoomRate(roomRate.getRoomRateId());

			roomRateToUpdate.setName(roomRate.getName());
			roomRateToUpdate.setRateType(roomRate.getRateType());
			roomRateToUpdate.setRatePerNight(roomRate.getRatePerNight());
			roomRateToUpdate.setValidityPeriodStart(roomRate.getValidityPeriodStart());
			roomRateToUpdate.setValidityPeriodEnd(roomRate.getValidityPeriodEnd());
			roomRateToUpdate.setStatus(roomRate.getStatus());

			em.merge(roomRateToUpdate);
			em.flush();
		} else {
			throw new RoomRateNotFoundException("Room Rate ID not provided for room type to be updated");
		}
	}

	@Override
	public void deleteRoomRate(Long roomRateId) throws RoomRateNotFoundException, DeleteRoomRateException {
		RoomRate roomRateToRemove = retrieveRoomRate(roomRateId);

		if (roomRateToRemove == null) {
			throw new RoomRateNotFoundException("Room Rate ID " + roomRateId + " does not exist!");
		}

		Query query = em.createQuery("SELECT r FROM RoomRate r WHERE r.roomRateId = :roomRate AND r.status = :activeStatus");
		query.setParameter("roomRate", roomRateId);
		query.setParameter("activeStatus", StatusEnum.AVAILABLE);

		// If there are active rooms (used), mark as disabled
		if (!query.getResultList().isEmpty()) {
			roomRateToRemove.setStatus(StatusEnum.DISABLED);
			em.merge(roomRateToRemove);
			throw new DeleteRoomRateException("Room Type is currently in use and has been marked as DISABLED.");
		} else {
			Query roomsQuery = em.createQuery("SELECT r FROM Room r WHERE r.roomType.roomTypeId = :roomTypeId");
			roomsQuery.setParameter("roomTypeId", roomRateToRemove.getRoomType().getRoomTypeId());
			List<RoomType> rooms = roomsQuery.getResultList();

			// Disconnect room rates from the rooms if applicable
			for (RoomType room : rooms) {
				room.getRoomRates().remove(roomRateToRemove); // Assuming roomRates is a List<RoomRate> in Room entity
				em.merge(room); // Ensure the changes are persisted
			}

			// Now we can safely remove the room rate without violating constraints
			em.remove(roomRateToRemove);
		}
	}

	@Override
	public RoomType retrieveRoomTypeByName(String name) throws RoomTypeNotFoundException {
		try {
			Query query = em.createQuery("SELECT rt FROM RoomType rt WHERE rt.name = :name");
			query.setParameter("name", name);
			return (RoomType) query.getSingleResult();
		} catch (NoResultException ex) {
			throw new RoomTypeNotFoundException("RoomType with name " + name + " does not exist.");
		}
	}

}
