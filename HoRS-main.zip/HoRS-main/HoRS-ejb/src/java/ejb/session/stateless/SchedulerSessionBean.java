package ejb.session.stateless;

import entity.AllocationReport;
import entity.ReservationDetail;
import entity.Room;
import entity.RoomType;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Schedule;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import util.enumeration.AllocationStatusEnum;
import util.exception.AllocationReportNotFoundException;
import util.exception.RoomNotFoundException;
import util.exception.RoomTypeNotFoundException;

@Stateless
public class SchedulerSessionBean implements SchedulerSessionBeanRemote, SchedulerSessionBeanLocal {

	@EJB
	private ReservationControllerSessionBeanLocal reservationControllerSessionBean;

	@EJB
	private RoomManagementSessionBeanLocal roomManagementSessionBean;

	@EJB
	private RoomAllocationSessionBeanLocal roomAllocationSessionBean;

	@Override
	@Schedule(hour = "2", minute = "0", persistent = false)
	public void automatedRoomAllocation() {
		LocalTime now = LocalTime.now();
		if (now.getHour() == 2 && now.getMinute() == 0) {
			System.out.println("Allocating done at 2 am only");
			doRoomAllocationAuto();
		} else {
			System.out.println("Ignoring initial deployment run");
		}
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public void doRoomAllocationAuto() {
		System.out.println("*** Starting Automatic Room Allocation ***");

		Date checkInDate = new Date();  // Automatically gets the current date
		//Retrieve reservation details by date
		List<ReservationDetail> reservationDetails = null;
		try {
			reservationDetails = reservationControllerSessionBean.retrieveReservationDetailsByDate(checkInDate);
			if (reservationDetails == null || reservationDetails.isEmpty()) {
				System.out.println("No reservations found for the entered date: " + checkInDate);
				return;
			} else {
				System.out.println("Found reservations: " + reservationDetails.size());
			}
		} catch (Exception e) {
			System.err.println("Error retrieving reservation details: " + e.getMessage());
			e.printStackTrace();
			return;
		}

		// Retrieve allocated reservations for the date
		List<ReservationDetail> allocatedReservationDetails = null;
		try {
			allocatedReservationDetails = roomAllocationSessionBean.retrieveReservationDetailByDate(checkInDate);
			if (allocatedReservationDetails == null) {
				System.out.println("No allocated reservations found for the entered date.");
				allocatedReservationDetails = new ArrayList<>();
			} else {
				System.out.println("Found allocated reservations: " + allocatedReservationDetails.size());
			}
		} catch (AllocationReportNotFoundException ex) {
			System.err.println("Error in retrieving allocated reservations: " + ex.getMessage());
			ex.printStackTrace();
			return;
		}

		// Room allocation logic
		for (ReservationDetail reservation : reservationDetails) {
			if (reservation.getRoomType() == null || reservation.getRoomType().getRoomTypeId() == null) {
				System.err.println("Error: Room type data missing for reservation ID: " + reservation.getReservationDetailId());
				continue;
			}

			Integer numOfRooms = reservation.getNumOfRooms();
			Long roomTypeId = reservation.getRoomType().getRoomTypeId();
			boolean isAlreadyAllocated = false;

			// Check if the reservation is already allocated
			for (ReservationDetail allocatedReservation : allocatedReservationDetails) {
				if (reservation.getReservationDetailId().equals(allocatedReservation.getReservationDetailId())) {
					isAlreadyAllocated = true;
					break;
				}
			}

			if (!isAlreadyAllocated) {
				try {
					System.out.println("Allocating rooms for reservation ID: " + reservation.getReservationDetailId());
					roomAllocation(numOfRooms, roomTypeId, reservation, checkInDate);
					allocatedReservationDetails.add(reservation);
				} catch (Exception e) {
					System.err.println("Error during room allocation for reservation ID " + reservation.getReservationDetailId() + ": " + e.getMessage());
					e.printStackTrace();
				}
			} else {
				System.out.println("Reservation ID: " + reservation.getReservationDetailId() + " already allocated.");
			}
		}
		System.out.println("*** Room Allocation Complete ***");
	}
	
	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public void roomAllocation(Integer numOfRooms, Long roomTypeId, ReservationDetail reservationDetail, Date checkInDate) {
		
		roomAllocationSameDay(numOfRooms,  roomTypeId,  reservationDetail,  checkInDate);
	}

	@Override
	public void roomAllocationSameDay(Integer numOfRooms, Long roomTypeId, ReservationDetail reservationDetail, Date checkInDate) {
		RoomType roomType;

		try {
			roomType = roomManagementSessionBean.retrieveRoomType(roomTypeId);
			roomType.getRooms().size();  
			
		} catch (RoomTypeNotFoundException ex) {
			System.out.println("Room type not found: " + ex.getMessage());
			return; 
		}

		List<Room> availableRooms = new ArrayList<>();
		List<Integer> allocatedRoomsRecord = new ArrayList<>();

		try {
			allocatedRoomsRecord = roomAllocationSessionBean.retrieveAListOfAllocatedRoomsNumber();
			
		} catch (RoomNotFoundException e) {
			System.out.println(e);
			
		}
		
		if (allocatedRoomsRecord != null && allocatedRoomsRecord.isEmpty()) {
			if (roomType.getRooms() != null) {
				availableRooms.addAll(roomType.getRooms());
			}
			
		} else {
			if (roomType.getRooms() != null) {
				for (Room room : roomType.getRooms()) {
					boolean isAllocated = false;
					if (allocatedRoomsRecord != null) {
						for (Integer allocatedRoom : allocatedRoomsRecord) {
							if (room.getRoomNumber().equals(allocatedRoom)) {
								isAllocated = true;
								break; // Room is allocated, skip adding
							}
						}
					}
					if (!isAllocated) {
						availableRooms.add(room); // Room is not allocated, add to availableRooms
					}
				}
			}
		}

		if (availableRooms.isEmpty()) {
			System.out.println("No available rooms for the selected room type.");
		}

		// Allocate as many rooms as are available
		int roomCountToAllocate = Math.min(numOfRooms, availableRooms.size());
		List<Room> allocatedRooms = availableRooms.subList(0, roomCountToAllocate);

		System.out.println("Allocated rooms: " + allocatedRooms.size() + " room(s).");

		for (Room room : allocatedRooms) {
			//room.setStatus(StatusEnum.ACTIVE);
			// Persist the room status change back to the database using merge
			try {

				AllocationReport allocationReport = new AllocationReport();
				//roomManagementSessionBeanRemote.updateRoom(room);
				//create the allocationReport entity
				allocationReport.setRoomNumber(room.getRoomNumber());
				allocationReport.setCheckInDate(checkInDate);
				// allocationReport.setStatus(StatusEnum.ACTIVE);
				allocationReport.setAllocationStatus(AllocationStatusEnum.ALLOCATED);

				//the culprit if things goes south
				roomAllocationSessionBean.createNewAllocationRecord(reservationDetail, allocationReport);
				// roomAllocationSessionBeanRemote.linkAllocationToReservation(reservationDetail,allocationReport);

				// Here, you can use the merge() in your session bean
				System.out.println("Room " + room.getRoomNumber() + " reserved and persisted.");
			} catch (Exception e) {
				System.out.println("Failed to persist room " + room.getRoomNumber() + ": " + e.getMessage());
			}
			// Optionally persist these changes back to the database if necessary
			System.out.println("Room " + room.getRoomNumber() + " reserved.");
		}
		if (allocatedRooms.size() >= numOfRooms) {
			System.out.println("All required rooms have been allocated. No upgrade needed.");
			return; // Early return to avoid unnecessary upgrade logic
		}

		if (allocatedRooms.size() < numOfRooms) {
			int shortage = numOfRooms - allocatedRooms.size(); // Calculate the shortage
			System.out.println("Partial allocation: " + shortage + " more room(s) needed or unavailable.");
			System.out.println("Looking for an upgrade....");

			// Step 1: Prepare lists for upgraded rooms
			List<Room> upgradedRooms = new ArrayList<>();          // Rooms to be upgraded
			List<Integer> upgradeRoomRecord = new ArrayList<>();   // Record of rooms already upgraded/allocated
			List<Room> availableUpgradeRooms = new ArrayList<>();  // Rooms available for upgrading
			Integer upgradedRank = null;

			// Step 2: Fetch the next room rank (upgraded rooms)
			try {
				upgradedRank = roomManagementSessionBean.retrieveRoomType(roomTypeId).getRanking() + 1;
			} catch (RoomTypeNotFoundException ex) {
				System.out.println("Rank not found: " + ex.getMessage());
				return; 
			}

			// Step 3: Retrieve rooms of higher rank (upgraded rooms)
			try {
				upgradedRooms = roomManagementSessionBean.retrieveRoomsByRank(upgradedRank);
				if (upgradedRooms.isEmpty()) {
					System.out.println("No rooms found for the upgraded rank.");
					return;  
				}
			} catch (RoomTypeNotFoundException e) {
				System.out.println("No RoomType Found for upgraded rank: " + e.getMessage());
				return; 
			}

			// Step 4: Retrieve the list of rooms already upgraded or allocated
			try {
				upgradeRoomRecord = roomAllocationSessionBean.retrieveAListOfAllocatedRoomsNumber();
			} catch (RoomNotFoundException e) {
				System.out.println("Error retrieving allocated room numbers: " + e.getMessage());
			}

			// Step 5: Filter upgraded room list by removing rooms already allocated/upgraded
			for (Room room : upgradedRooms) {
				boolean isAlreadyAllocated = false;
				
				// Check if this room is already in the allocated list
				for (Integer allocatedRoomNumber : upgradeRoomRecord) {
					if (room.getRoomNumber().equals(allocatedRoomNumber)) {
						isAlreadyAllocated = true; // Mark as already allocated and skip
						break;
					}
				}
				
				// If the room is NOT allocated, add it to the available upgrade rooms list
				if (!isAlreadyAllocated) {
					availableUpgradeRooms.add(room);
				}
			}

			// Step 6: Validate if we have enough rooms to upgrade
			if (availableUpgradeRooms.size() < shortage) {
				// Not enough rooms for the upgrade, immediately mark as `NOT_UPGRADED`
				System.out.println("Not enough rooms are available for upgrade.");

				try {
					AllocationReport allocationReport = new AllocationReport();
					allocationReport.setAllocationStatus(AllocationStatusEnum.NOT_UPGRADED);
					roomAllocationSessionBean.createNewAllocationRecord(reservationDetail, allocationReport);
					System.out.println("Marked as NOT_UPGRADED due to insufficient upgradeable rooms.");
				} catch (Exception e) {
					System.out.println("Error generating NOT_UPGRADED report: " + e.getMessage());
				}

				return;  // Exit because we can't proceed with upgrading
			}

			// Step 7: Allocate rooms as there are enough available upgrade rooms
			int roomsToUpgrade = shortage;  // Since shortage == availableUpgradeRooms.size() has been validated
			List<Room> allocatedUpgradedRooms = availableUpgradeRooms.subList(0, roomsToUpgrade);

			System.out.println("Allocated upgraded rooms: " + allocatedUpgradedRooms.size() + " room(s).");

			// Step 8: Mark upgraded rooms and persist them
			for (Room upgradeRoom : allocatedUpgradedRooms) {
				try {
					// Create the allocation report for each upgraded room
					AllocationReport allocationReport = new AllocationReport();
					allocationReport.setRoomNumber(upgradeRoom.getRoomNumber());
					allocationReport.setCheckInDate(checkInDate);
					allocationReport.setAllocationStatus(AllocationStatusEnum.UPGRADED);

					// Persist the newly upgraded record
					roomAllocationSessionBean.createNewAllocationRecord(reservationDetail, allocationReport);
					System.out.println("Room " + upgradeRoom.getRoomNumber() + " upgraded and persisted.");
				} catch (Exception e) {
					System.out.println("Failed to upgrade room " + upgradeRoom.getRoomNumber() + ": " + e.getMessage());
				}
			}

		} else {

			try {
				AllocationReport allocationReport = new AllocationReport();
				allocationReport.setAllocationStatus(AllocationStatusEnum.NOT_UPGRADED);
				allocationReport.setCheckInDate(checkInDate);
				roomAllocationSessionBean.createNewAllocationRecord(reservationDetail, allocationReport);
				System.out.println("Marked as NOT_UPGRADED since no upgrade was required.");
			} catch (Exception e) {
				System.out.println("Error generating NOT_UPGRADED report: " + e.getMessage());
			}
		}
	}
}
