package ejb.session.stateless;

import entity.PartnerEmployee;
import java.util.List;
import javax.ejb.Local;
import util.exception.EmployeeUsernameExistException;
import util.exception.InputDataValidationException;
import util.exception.InvalidLoginCredentialException;
import util.exception.PartnerNotFoundException;
import util.exception.UnknownPersistenceException;

@Local
public interface PartnerEmployeeSessionBeanLocal {

	public Long createNewPartnerEmployee(PartnerEmployee newPartnerEmployee) throws EmployeeUsernameExistException, UnknownPersistenceException, InputDataValidationException;
	public List<PartnerEmployee> retrieveAllPartners();
	public PartnerEmployee retrievePartnerByUsername(String username) throws PartnerNotFoundException;
	public PartnerEmployee partnerEmployeeLogin(String username, String password) throws InvalidLoginCredentialException;
	public PartnerEmployee retrievePartnerById(Long partnerEmployeeId) throws PartnerNotFoundException;

}
