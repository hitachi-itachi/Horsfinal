package ejb.session.stateless;

import entity.RoomRate;
import entity.RoomType;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import util.enumeration.RateTypeEnum;
import util.enumeration.StatusEnum;

@Stateless
public class OnlineReservationSessionBean implements OnlineReservationSessionBeanRemote, OnlineReservationSessionBeanLocal {

	@PersistenceContext(unitName = "HoRS-ejbPU")
	private EntityManager em;

	public OnlineReservationSessionBean() {
	}

	@Override
	public BigDecimal calculateAmount(RoomType roomType, int numRoomsToReserve, Date checkInDate, Date checkOutDate) {
		BigDecimal totalAmount = BigDecimal.ZERO;
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(checkInDate);

		// Calculate the rate for each night and accumulate
		while (calendar.getTime().before(checkOutDate)) {
			Date currentDate = calendar.getTime();
			BigDecimal nightlyRate = chooseRoomRateForDate(roomType, currentDate);
			totalAmount = totalAmount.add(nightlyRate.multiply(BigDecimal.valueOf(numRoomsToReserve)));
			calendar.add(Calendar.DATE, 1);  
		}
		
		return totalAmount;
	}

	private BigDecimal chooseRoomRateForDate(RoomType roomType, Date date) {

		BigDecimal rate = findRateByTypeAndDate(roomType, RateTypeEnum.PROMOTION, date);
		if (rate != null) {
			return rate;
		}

		rate = findRateByTypeAndDate(roomType, RateTypeEnum.PEAK, date);
		if (rate != null) {
			return rate;
		}

		return findRateByTypeAndDate(roomType, RateTypeEnum.NORMAL, date);
	}

	private BigDecimal findRateByTypeAndDate(RoomType roomType, RateTypeEnum rateType, Date date) {
		Query query;

		if (rateType == RateTypeEnum.NORMAL) {
			// Query for Normal Rate
			query = em.createQuery(
					"SELECT rr.ratePerNight FROM RoomRate rr "
					+ "WHERE rr.roomType = :roomType AND rr.rateType = :rateType AND rr.status = :status");
		} else {
			// Peak and Promotion Rates
			query = em.createQuery(
					"SELECT rr.ratePerNight FROM RoomRate rr "
					+ "WHERE rr.roomType = :roomType AND rr.rateType = :rateType AND rr.status = :status "
					+ "AND rr.validityPeriodStart <= :date AND rr.validityPeriodEnd >= :date");
			query.setParameter("date", date);
		}

		query.setParameter("roomType", roomType);
		query.setParameter("rateType", rateType);
		query.setParameter("status", StatusEnum.AVAILABLE);

		List<BigDecimal> results = query.getResultList();
		return results.isEmpty() ? null : results.get(0);
	}

}
