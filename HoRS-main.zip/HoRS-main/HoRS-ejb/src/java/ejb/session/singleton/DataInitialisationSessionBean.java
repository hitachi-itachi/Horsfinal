package ejb.session.singleton;

import entity.Employee;
import entity.Room;
import entity.RoomRate;
import entity.RoomType;
import javax.annotation.PostConstruct;
import javax.ejb.Singleton;
import javax.ejb.LocalBean;
import javax.ejb.Startup;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.math.BigDecimal;
import util.enumeration.AllocationStatusEnum;
import util.enumeration.EmployeeRoleEnum;
import util.enumeration.RateTypeEnum;
import util.enumeration.StatusEnum;

@Singleton
@LocalBean
@Startup
public class DataInitialisationSessionBean {

	@PersistenceContext(unitName = "HoRS-ejbPU")
	private EntityManager em;

	public DataInitialisationSessionBean() {
	}

	@PostConstruct
	public void postConstruct() {
		// Only initialize data if there are no employees in the database
		if (em.find(Employee.class, 1L) == null) {
			initializeData();
		}
	}

	private void initializeData() {
		initializeEmployees();
		initializeRoomTypes();
		initializeRooms();
		initializeRoomRates();
	}

	private void initializeEmployees() {
		em.persist(new Employee("John", "Doe", "sysadmin", "password", EmployeeRoleEnum.SYSTEMADMINISTRATOR));
		em.persist(new Employee("Jane", "Doe", "salesmanager", "password", EmployeeRoleEnum.SALESMANAGER));
		em.persist(new Employee("John", "Smith", "opmanager", "password", EmployeeRoleEnum.OPERATIONMANAGER));
		em.persist(new Employee("John", "L", "guestrelo", "password", EmployeeRoleEnum.GUESTRELATIONOFFICER));

		em.flush();
		System.out.println("Employees initialized.");
	}

	private void initializeRoomTypes() {
		
		RoomType grandRoomType = new RoomType("Grand Suite", "Spacious grand suite with 5 rooms", "55 sqm", "King Bed", 5, "WiFi, TV, Air Conditioning", StatusEnum.AVAILABLE, 5, null);
		RoomType juniorRoomType = new RoomType("Junior Suite", "Spacious junior suite with 4 rooms", "48 sqm", "Queen Bed", 5, "WiFi, TV", StatusEnum.AVAILABLE, 4, grandRoomType);
		RoomType familyRoomType = new RoomType("Family Room", "Spacious family room with 3 rooms", "35 sqm", "Queen Bed", 5, "WiFi, TV", StatusEnum.AVAILABLE, 3, juniorRoomType);
		RoomType premierRoomType = new RoomType("Premier Room", "Spacious premier room with 2 rooms", "30 sqm", "Queen Bed", 5, "WiFi, TV", StatusEnum.AVAILABLE, 2, familyRoomType);
		RoomType deluxeRoomType = new RoomType("Deluxe Room", "Spacious deluxe room with 1 room", "25 sqm", "Queen Bed", 5, "WiFi, TV", StatusEnum.AVAILABLE, 1, premierRoomType);
		
		em.persist(grandRoomType);
		em.persist(juniorRoomType);
		em.persist(familyRoomType);
		em.persist(premierRoomType);
		em.persist(deluxeRoomType);
		em.flush();
	
		System.out.println("Room Types initialized.");
	}

	private void initializeRooms() {
		Object[][] roomData = {
			{"Deluxe Room", new String[]{"0101", "0201", "0301", "0401", "0501"}},
			{"Premier Room", new String[]{"0102", "0202", "0302", "0402", "0502"}},
			{"Family Room", new String[]{"0103", "0203", "0303", "0403", "0503"}},
			{"Junior Suite", new String[]{"0104", "0204", "0304", "0404", "0504"}},
			{"Grand Suite", new String[]{"0105", "0205", "0305", "0405", "0505"}}
		};

		for (Object[] roomTypeData : roomData) {
			RoomType roomType = em.createQuery("SELECT r FROM RoomType r WHERE r.name = :name", RoomType.class)
					.setParameter("name", (String) roomTypeData[0])
					.getSingleResult();
			String[] roomNumbers = (String[]) roomTypeData[1];

			for (String roomNumber : roomNumbers) {
				Room room = new Room();
				room.setRoomNumber(Integer.parseInt(roomNumber));
				room.setStatus(StatusEnum.AVAILABLE);
				room.setRoomType(roomType);
				roomType.getRooms().add(room);
				em.persist(room);
			}
		}

		em.flush();
		System.out.println("Rooms initialized successfully.");
	}

	private void initializeRoomRates() {
		Object[][] roomRateData = {
			{"Deluxe Room", "Deluxe Room Published", RateTypeEnum.PUBLISHED, new BigDecimal("100")},
			{"Deluxe Room", "Deluxe Room Normal", RateTypeEnum.NORMAL, new BigDecimal("50")},
			{"Premier Room", "Premier Room Published", RateTypeEnum.PUBLISHED, new BigDecimal("200")},
			{"Premier Room", "Premier Room Normal", RateTypeEnum.NORMAL, new BigDecimal("100")},
			{"Family Room", "Family Room Published", RateTypeEnum.PUBLISHED, new BigDecimal("300")},
			{"Family Room", "Family Room Normal", RateTypeEnum.NORMAL, new BigDecimal("150")},
			{"Junior Suite", "Junior Suite Published", RateTypeEnum.PUBLISHED, new BigDecimal("400")},
			{"Junior Suite", "Junior Suite Normal", RateTypeEnum.NORMAL, new BigDecimal("200")},
			{"Grand Suite", "Grand Suite Published", RateTypeEnum.PUBLISHED, new BigDecimal("500")},
			{"Grand Suite", "Grand Suite Normal", RateTypeEnum.NORMAL, new BigDecimal("250")}
		};

		for (Object[] rateData : roomRateData) {
			RoomType roomType = em.createQuery("SELECT r FROM RoomType r WHERE r.name = :name", RoomType.class)
					.setParameter("name", (String) rateData[0])
					.getSingleResult();
			String rateName = (String) rateData[1];
			RateTypeEnum rateType = (RateTypeEnum) rateData[2];
			BigDecimal price = (BigDecimal) rateData[3];

			RoomRate roomRate = new RoomRate(rateName, rateType, price, null, null, StatusEnum.AVAILABLE);
			roomRate.setRoomType(roomType);
			roomType.getRoomRates().add(roomRate);
			em.persist(roomRate);
		}

		em.flush();
		System.out.println("Room Rates initialized.");
	}
}
