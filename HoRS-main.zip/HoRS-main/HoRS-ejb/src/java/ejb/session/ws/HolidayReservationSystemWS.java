package ejb.session.ws;

import ejb.session.stateless.OnlineReservationSessionBeanLocal;
import ejb.session.stateless.PartnerEmployeeSessionBeanLocal;
import ejb.session.stateless.ReservationControllerSessionBeanLocal;
import ejb.session.stateless.RoomManagementSessionBeanLocal;
import entity.OnlineReservation;
import entity.PartnerEmployee;
import entity.PartnerReservation;
import entity.Reservation;
import entity.ReservationDetail;
import entity.Room;
import entity.RoomRate;
import entity.RoomType;
import entity.WalkInReservation;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import util.enumeration.StatusEnum;
import util.exception.InvalidLoginCredentialException;
import util.exception.ReservationNotFoundException;

@WebService(serviceName = "HolidayReservationSystemWS")
@Stateless()
public class HolidayReservationSystemWS {

	@EJB
	private OnlineReservationSessionBeanLocal onlineReservationSessionBeanLocal;

	@EJB
	private ReservationControllerSessionBeanLocal reservationControllerSessionBeanLocal;

	@EJB
	private RoomManagementSessionBeanLocal roomManagementSessionBeanLocal;

	@EJB
	private PartnerEmployeeSessionBeanLocal partnerEmployeeSessionBeanLocal;

	@PersistenceContext(unitName = "HoRS-ejbPU")
	private EntityManager em;

	@WebMethod(operationName = "searchAvailableRoomTypes")
	public List<RoomAvailabilityResponse> searchAvailableRoomTypes(
			@WebParam(name = "checkInDate") Date checkInDate,
			@WebParam(name = "checkOutDate") Date checkOutDate) {

		List<RoomAvailabilityResponse> availableRoomTypes = new ArrayList<>();
		List<RoomType> roomTypes = roomManagementSessionBeanLocal.retrieveAllRoomTypes();

		for (RoomType roomType : roomTypes) {
			if (roomType.getRoomRates().isEmpty()) {
				continue; // Skip room types without associated room rates
			}
			
			int totalRooms = roomType.getRooms().size();
			int availableRooms = totalRooms;

			// Deduct rooms that are not in active status
			for (Room room : roomType.getRooms()) {
				if (room.getStatus().equals(StatusEnum.DISABLED)) {
					availableRooms--;
				}
			}

			List<ReservationDetail> reservations = reservationControllerSessionBeanLocal.retrieveReservationDetailsByRoomTypeAndDate(roomType, checkInDate, checkOutDate);
			for (ReservationDetail reservationDetail : reservations) {
				availableRooms -= reservationDetail.getNumOfRooms();
			}

			if (availableRooms > 0) {
				em.detach(roomType);

				roomType.setRooms(null);
				roomType.setRoomRates(null);

				availableRoomTypes.add(new RoomAvailabilityResponse(roomType, availableRooms));
			}
		}

		return availableRoomTypes;
	}

	@WebMethod(operationName = "createPartnerReservation")
	public Long createPartnerReservation(
			@WebParam(name = "partnerId") Long partnerId,
			@WebParam(name = "checkInDate") Date checkInDate,
			@WebParam(name = "checkOutDate") Date checkOutDate,
			@WebParam(name = "roomTypesToReserve") List<RoomTypeReservationRequest> roomTypesToReserve) {

		try {
			PartnerReservation newPartnerReservation = new PartnerReservation();
			newPartnerReservation.setStartDate(checkInDate);
			newPartnerReservation.setEndDate(checkOutDate);

			PartnerEmployee partnerEmployee = partnerEmployeeSessionBeanLocal.retrievePartnerById(partnerId);
			newPartnerReservation.setPartnerEmployee(partnerEmployee);

			BigDecimal totalAmount = BigDecimal.ZERO;

			Map<RoomType, Integer> roomTypesMap = new HashMap<>();
			for (RoomTypeReservationRequest request : roomTypesToReserve) {
				roomTypesMap.put(request.getRoomType(), request.getQuantity());
			}

			for (Map.Entry<RoomType, Integer> entry : roomTypesMap.entrySet()) {
				RoomType roomType = entry.getKey();
				int numRooms = entry.getValue();

				ReservationDetail reservationDetail = new ReservationDetail();
				reservationDetail.setNumOfRooms(numRooms);
				reservationDetail.setRoomType(roomType);
				newPartnerReservation.getReservationDetails().add(reservationDetail);

				BigDecimal amount = onlineReservationSessionBeanLocal.calculateAmount(roomType, numRooms, checkInDate, checkOutDate);
				totalAmount = totalAmount.add(amount);
			}

			newPartnerReservation.setReservationFee(totalAmount);
			PartnerReservation reservation = reservationControllerSessionBeanLocal.createNewPartnerReservation(partnerId, newPartnerReservation);
			return reservation.getReservationId();

		} catch (Exception e) {
			System.out.println("Error creating reservation: " + e.getMessage());
			return null;
		}
	}

	@WebMethod(operationName = "login")
	public PartnerEmployee login(
			@WebParam(name = "username") String username,
			@WebParam(name = "password") String password) throws InvalidLoginCredentialException {
		try {
			PartnerEmployee partnerEmployee = partnerEmployeeSessionBeanLocal.partnerEmployeeLogin(username, password);
			em.detach(partnerEmployee);
			partnerEmployee.setPartnerReservations(null);

			return partnerEmployee;
		} catch (InvalidLoginCredentialException ex) {
			System.out.println("Login failed: " + ex.getMessage());
			return null;
		}
	}

	@WebMethod(operationName = "retrieveReservationById")
	public Reservation retrieveReservationById(@WebParam(name = "reservationId") Long reservationId) throws ReservationNotFoundException {
		try {
			Reservation reservation = reservationControllerSessionBeanLocal.retrieveReservationById(reservationId);
			
			if (reservation == null) {
				throw new ReservationNotFoundException("Reservation with ID " + reservationId + " does not exist.");
			}
			
			if (!(reservation instanceof PartnerReservation)) {
				throw new ReservationNotFoundException("Reservation with ID " + reservationId + " is not a partner reservation.");
			}
			
			em.detach(reservation);
			
			if (reservation instanceof PartnerReservation) {
				((PartnerReservation) reservation).setPartnerEmployee(null);
			} 

			for (ReservationDetail detail : reservation.getReservationDetails()) {
				RoomType roomType = detail.getRoomType();
				if (roomType != null) {
					roomType.setRoomRates(null); 
					roomType.setRooms(null);     

					em.detach(roomType); 

					// Nullify back references to roomType
					for (RoomRate rate : roomType.getRoomRates()) {
						rate.setRoomType(null); 
					}

					for (Room room : roomType.getRooms()) {
						room.setRoomType(null); 
					}
				}
			}

			return reservation;

		} catch (ReservationNotFoundException ex) {
			System.out.println(ex.getMessage());
			return null;
		}
	}

	@WebMethod(operationName = "viewAllReservations")
	public List<Reservation> retrieveAllReservations(@WebParam(name = "partnerId") Long partnerId) {
		List<Reservation> reservations = reservationControllerSessionBeanLocal.retrievePartnerReservationsByPartnerId(partnerId);
		for (Reservation r : reservations) {
			em.detach(r);

			if (r instanceof PartnerReservation) {
				((PartnerReservation) r).setPartnerEmployee(null);
			}

			r.setReservationDetails(null);

		}

		return reservations;
	}
	
	@WebMethod(operationName = "calculateReservationFee")
	public BigDecimal calculateReservationFee(
			@WebParam(name = "roomType") RoomType roomType,
			@WebParam(name = "quantity") int quantity,
			@WebParam(name = "checkInDate") Date checkInDate,
			@WebParam(name = "checkOutDate") Date checkOutDate) {

		return onlineReservationSessionBeanLocal.calculateAmount(roomType, quantity, checkInDate, checkOutDate);
	}

}
