package ejb.session.ws;

import entity.RoomType;  

public class RoomAvailabilityResponse {

	private RoomType roomType;  
	private int availableRooms;

	public RoomAvailabilityResponse() {
	}

	public RoomAvailabilityResponse(RoomType roomType, int availableRooms) {
		this.roomType = roomType;
		this.availableRooms = availableRooms;
	}

	public RoomType getRoomType() {
		return roomType;
	}

	public void setRoomType(RoomType roomType) {
		this.roomType = roomType;
	}

	public int getAvailableRooms() {
		return availableRooms;
	}

	public void setAvailableRooms(int availableRooms) {
		this.availableRooms = availableRooms;
	}
}
