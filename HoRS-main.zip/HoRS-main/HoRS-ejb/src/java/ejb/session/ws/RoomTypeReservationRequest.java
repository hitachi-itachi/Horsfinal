package ejb.session.ws;

import entity.RoomType;
import java.io.Serializable;

public class RoomTypeReservationRequest implements Serializable {

	private RoomType roomType;
	private int quantity;

	public RoomTypeReservationRequest() {
	}

	public RoomTypeReservationRequest(RoomType roomType, int quantity) {
		this.roomType = roomType;
		this.quantity = quantity;
	}

	public RoomType getRoomType() {
		return roomType;
	}

	public void setRoomType(RoomType roomType) {
		this.roomType = roomType;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
}
