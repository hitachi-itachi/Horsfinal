package holidayreservationsystem;

import java.util.Scanner;

public class HolidayReservationSystem {

	public static void main(String[] args) {
		
		MainApp mainApp = new MainApp();
		mainApp.runApp();
	}

}
