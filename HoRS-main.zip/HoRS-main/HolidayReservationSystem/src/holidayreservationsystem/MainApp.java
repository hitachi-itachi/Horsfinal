package holidayreservationsystem;

import client.ws.CreatePartnerReservation;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import client.ws.HolidayReservationSystemWS;
import client.ws.HolidayReservationSystemWS_Service;
import client.ws.InvalidLoginCredentialException;
import client.ws.InvalidLoginCredentialException_Exception;
import client.ws.ReservationNotFoundException;
import client.ws.ReservationNotFoundException_Exception;
import client.ws.PartnerEmployee;
import client.ws.Reservation;
import client.ws.ReservationDetail;
import client.ws.RoomAvailabilityResponse;
import client.ws.RoomTypeReservationRequest;
import client.ws.RoomType;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;

public class MainApp {

	private HolidayReservationSystemWS_Service service;
	private HolidayReservationSystemWS port;
	private PartnerEmployee currentPartnerEmployee;

	public MainApp() {
		service = new HolidayReservationSystemWS_Service();
		port = service.getHolidayReservationSystemWSPort();
	}

	public void runApp() {
		Scanner scanner = new Scanner(System.in);
		Integer response;

		while (true) {
			System.out.println("\n*** Welcome to Holiday Reservation System***\n");
			System.out.println("1: Partner Login");
			System.out.println("2: Partner Search Room");
			System.out.println("3: Exit\n");
			response = 0;

			while (response < 1 || response > 3) {
				System.out.print("> ");
				String input = scanner.nextLine().trim();
				
				try {
					response = Integer.parseInt(input);

					if (response == 1) {
						doLogin();
						if (currentPartnerEmployee != null) {
							menuMain();
						} else {
							System.out.println("Returning to main menu...8");
						}
					} else if (response == 2) {
						doSearchRoom();
					} else if (response == 3) {
						break;
					} else {
						System.out.print("Invalid option, please try again!\n");
					}
				} catch(NumberFormatException ex) {
					System.out.println("Invalid input. Please enter a valid number.\n");
				}

				if (response == 3) {
					break;
				}
			}
		}
	}

	private void doLogin() {
		Scanner scanner = new Scanner(System.in);

		System.out.println("*** Holiday Reservation System :: Partner Log In ***\n");

		System.out.print("Enter username> ");
		String username = scanner.nextLine().trim();
		System.out.print("Enter password> ");
		String password = scanner.nextLine().trim();
		try {
			currentPartnerEmployee = port.login(username, password);

			if (currentPartnerEmployee == null) {
				System.out.println("Login failed. Invalid username or password.");
			} else {
				System.out.println("Login successful. Welcome " + currentPartnerEmployee.getFirstName() + "!");
			}

		} catch (InvalidLoginCredentialException_Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public void doSearchRoom() {
		Scanner scanner = new Scanner(System.in);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

		try {
			System.out.print("Enter check-in date (yyyy-MM-dd): ");
			Date checkInDate = dateFormat.parse(scanner.nextLine().trim());
			XMLGregorianCalendar checkInXML = convertToXMLGregorianCalendar(checkInDate);

			System.out.print("Enter check-out date (yyyy-MM-dd): ");
			Date checkOutDate = dateFormat.parse(scanner.nextLine().trim());
			XMLGregorianCalendar checkOutXML = convertToXMLGregorianCalendar(checkOutDate);

			// Call the web service
			List<RoomAvailabilityResponse> availableRooms = port.searchAvailableRoomTypes(checkInXML, checkOutXML);

			// Display the results
			System.out.println("\nAvailable Room Types:");
			if (availableRooms.isEmpty()) {
				System.out.println("No rooms available for the selected dates.");
			} else {
				int index = 1;
				for (RoomAvailabilityResponse availability : availableRooms) {
					RoomType roomType = availability.getRoomType();
					int availableRoomsCount = availability.getAvailableRooms();
					System.out.println(index++ + ". " + roomType.getName() + " - Available Rooms: " + availableRoomsCount);
				}
			}

		} catch (ParseException ex) {
			System.out.println("Invalid date format. Please enter the date in yyyy-MM-dd format.");
		} catch (Exception ex) {
			System.out.println("An error occurred while searching for available rooms: " + ex.getMessage());
		}
	}

	public void menuMain() {

		Scanner scanner = new Scanner(System.in);
		Integer response = 0;

		while (true) {
			System.out.println("\n*** Holiday Reservation System ***\n");
			System.out.println("You are login as " + currentPartnerEmployee.getFirstName() + " " + currentPartnerEmployee.getLastName() + "\n");

			System.out.println("1: Search Hotel Room");
			System.out.println("2: View Partner Reservation Details");
			System.out.println("3: View All Partner Reservations");
			System.out.println("4: Logout\n");
			response = 0;

			while (response < 1 || response > 4) {
				System.out.print("> ");
				response = scanner.nextInt();

				if (response == 1) {
					doPartnerSearchHotelRoom();
				} else if (response == 2) {
					doViewMyReservationDetails();
				} else if (response == 3) {
					doViewAllReservations();
				} else if (response == 4) {
					break;
				} else {
					System.out.println("Invalid option, please try again!\n");
				}
			}

			if (response == 4) {
				break;
			}

		}
	}

	public void doPartnerSearchHotelRoom() {
		try {
			Scanner scanner = new Scanner(System.in);
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

			System.out.println("*** Holiday Reservation System :: Search and Reserve Room ***\n");

			System.out.print("Enter check-in date (yyyy-MM-dd)> ");
			Date checkInDate = simpleDateFormat.parse(scanner.nextLine().trim());
			XMLGregorianCalendar checkInDateXML = convertToXMLGregorianCalendar(checkInDate);

			System.out.print("Enter check-out date (yyyy-MM-dd)> ");
			Date checkOutDate = simpleDateFormat.parse(scanner.nextLine().trim());
			XMLGregorianCalendar checkOutDateXML = convertToXMLGregorianCalendar(checkOutDate);

			// Call the web service to get available rooms
			List<RoomAvailabilityResponse> availableRooms = port.searchAvailableRoomTypes(checkInDateXML, checkOutDateXML);

			if (availableRooms.isEmpty()) {
				System.out.println("No rooms available for the selected dates.");
				return;
			}

			List<RoomTypeReservationRequest> roomTypesToReserve = new ArrayList<>();
			System.out.println("\nAvailable Room Types:");

			int index = 1;
			for (RoomAvailabilityResponse availability : availableRooms) {
				RoomType roomType = availability.getRoomType();
				int availableRoomsCount = availability.getAvailableRooms();
				System.out.println(index++ + ". " + roomType.getName() + " - Available Rooms: " + availableRoomsCount);
			}

			System.out.print("\nWould you like to make a reservation for these dates? (y/n): ");
			String response = scanner.nextLine().trim();
			if (!response.equalsIgnoreCase("y")) {
				System.out.println("Reservation canceled.");
				return;
			}

			BigDecimal totalReservationFee = BigDecimal.ZERO;
			System.out.println("\nSelect Room Types and Quantities for Reservation:");
			for (RoomAvailabilityResponse availability : availableRooms) {
				System.out.print("Enter quantity for " + availability.getRoomType().getName() + ": ");
				int quantity = Integer.parseInt(scanner.nextLine().trim());

				if (quantity != 0) {
					if (quantity <= availability.getAvailableRooms()) {
						RoomTypeReservationRequest r = new RoomTypeReservationRequest();
						r.setRoomType(availability.getRoomType());
						r.setQuantity(quantity);
						roomTypesToReserve.add(r);
						System.out.println(quantity + " rooms added for " + availability.getRoomType().getName() + ".");
						BigDecimal amountForRoomType = port.calculateReservationFee(availability.getRoomType(), quantity, checkInDateXML, checkOutDateXML);
						totalReservationFee = totalReservationFee.add(amountForRoomType);
					} else {
						System.out.println("Not enough rooms available for " + availability.getRoomType().getName() + ". Available: " + availability.getAvailableRooms());
					}
				}
			}

			System.out.println("The total reservation fee is: " + totalReservationFee);
			System.out.print("Would you like to proceed with the reservation? (y/n): ");
			response = scanner.nextLine().trim();

			if (!response.equalsIgnoreCase("y")) {
				System.out.println("Reservation canceled.");
				return;
			}

			// Call the web service to create the reservation
			Long reservationID = port.createPartnerReservation(currentPartnerEmployee.getPartnerEmployeeId(), checkInDateXML, checkOutDateXML, roomTypesToReserve);
			if (reservationID != null) {
				System.out.println("Reservation successful. Your Reservation ID is: " + reservationID);
			} else {
				System.out.println("Reservation process failed.");
			}

		} catch (ParseException e) {
			System.out.println("Invalid Date Input. Please use yyyy-MM-dd format.");
		} catch (Exception e) {
			System.out.println("An error occurred: " + e.getMessage());
		}
	}

	public void doViewMyReservationDetails() {
		Scanner scanner = new Scanner(System.in);
		DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		Long reservationId = null;
		System.out.println("*** Hotel Reservation System  :: View My Reservation Details***\n");
		
		while (reservationId == null) {
			System.out.print("Enter Reservation ID> ");
			String input = scanner.nextLine().trim();

			try {
				reservationId = Long.parseLong(input); // Try to parse input as a Long
			} catch (NumberFormatException e) {
				System.out.println("Invalid input. Please enter a valid numeric Reservation ID.");
			}
		}
		
		try {
			Reservation reservation = port.retrieveReservationById(reservationId);

			if (reservation == null) {
				System.out.println("Reservation with ID " + reservationId + " does not exist. Please try again with a valid ID.");
				return;
			}

			List<ReservationDetail> reservationDetails = reservation.getReservationDetails();

			String startDateFormatted = formatXMLGregorianCalendar(reservation.getStartDate(), outputFormatter);
			String endDateFormatted = formatXMLGregorianCalendar(reservation.getEndDate(), outputFormatter);

			System.out.printf("%10s%30s%30s%40s\n", "Reservation ID", "Start Date", "End Date", "Reservation Fee");
			System.out.printf("%10s%35s%35s%25s\n", reservation.getReservationId(), startDateFormatted, endDateFormatted, reservation.getReservationFee());

			System.out.println("Your reservation details are as follows: ");

			for (ReservationDetail rd : reservationDetails) {
				System.out.printf("%10s%30s\n", "Room Type", "Number of Rooms");
				System.out.printf("%10s%30s\n", rd.getRoomType().getName(), rd.getNumOfRooms());
			}
		} catch(ReservationNotFoundException_Exception ex) {
			System.out.println("Reservation with ID " + reservationId + " does not exist. Please try again with a valid ID.");
		}

	}

	public void doViewAllReservations() {
		//SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, yyyy-MM-dd");
		System.out.println("*** Hotel Reservation System  :: View All My Reservations ***\n");
		DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

		Long partnerId = currentPartnerEmployee.getPartnerEmployeeId();
		List<Reservation> reservations = port.viewAllReservations(partnerId);

		for (Reservation r : reservations) {

			String startDateFormatted = formatXMLGregorianCalendar(r.getStartDate(), outputFormatter);
			String endDateFormatted = formatXMLGregorianCalendar(r.getEndDate(), outputFormatter);
			System.out.printf("%10s%30s%30s%30s\n", "Reservation ID", "Start Date", "End Date", "Reservation Fee");
			System.out.printf("%10s%30s%30s%25s\n", r.getReservationId(), startDateFormatted, endDateFormatted, r.getReservationFee());

		}
	}

	private XMLGregorianCalendar convertToXMLGregorianCalendar(Date date) {
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		try {
			return DatatypeFactory.newInstance().newXMLGregorianCalendar(calendar);
		} catch (DatatypeConfigurationException e) {
			e.printStackTrace();
			return null;
		}
	}

	private String formatXMLGregorianCalendar(XMLGregorianCalendar xmlGregorianCalendar, DateTimeFormatter formatter) {
		if (xmlGregorianCalendar == null) {
			return "N/A";
		}
		LocalDate localDate = xmlGregorianCalendar.toGregorianCalendar().toZonedDateTime().toLocalDate();

		return localDate.format(formatter);
	}
}
