package util.exception;

public class CreateNewRoomRateException extends Exception {

	public CreateNewRoomRateException() {
	}

	public CreateNewRoomRateException(String msg) {
		super(msg);
	}
}
