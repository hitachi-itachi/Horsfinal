package util.exception;

public class ReservationDetailNotFoundException extends Exception{

    public ReservationDetailNotFoundException() {
    }

    public ReservationDetailNotFoundException(String msg) {
        super(msg);
    }
}

