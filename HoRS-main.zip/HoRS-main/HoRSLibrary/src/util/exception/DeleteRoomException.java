package util.exception;

public class DeleteRoomException extends Exception {

	public DeleteRoomException() {
	}

	public DeleteRoomException(String msg) {
		super(msg);
	}
}
