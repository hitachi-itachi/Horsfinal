package util.exception;

public class DuplicateRoomRateException extends Exception {

	public DuplicateRoomRateException() {
	}

	public DuplicateRoomRateException(String msg) {
		super(msg);
	}
}
