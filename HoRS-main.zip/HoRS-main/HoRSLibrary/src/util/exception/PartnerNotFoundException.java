package util.exception;

public class PartnerNotFoundException extends Exception {

    public PartnerNotFoundException() {
    }
    
    public PartnerNotFoundException(String msg) {
		super(msg);
	}
}
