package util.exception;

public class UpdateRoomException extends Exception {

	public UpdateRoomException() {
	}

	public UpdateRoomException(String msg) {
		super(msg);
	}
}
