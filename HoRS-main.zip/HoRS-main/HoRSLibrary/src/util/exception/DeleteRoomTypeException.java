package util.exception;

public class DeleteRoomTypeException extends Exception {

	public DeleteRoomTypeException() {
	}

	public DeleteRoomTypeException(String msg) {
		super(msg);
	}
}
