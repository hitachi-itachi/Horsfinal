package util.exception;

public class CreateNewRoomException extends Exception {

	public CreateNewRoomException() {
	}

	public CreateNewRoomException(String msg) {
		super(msg);
	}
}
