package util.exception;

public class CreateNewWalkInReservationException extends Exception {

	public CreateNewWalkInReservationException() {
	}

	public CreateNewWalkInReservationException(String msg) {
		super(msg);
	}
}
