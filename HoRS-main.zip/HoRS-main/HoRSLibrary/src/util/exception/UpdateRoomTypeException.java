package util.exception;

public class UpdateRoomTypeException extends Exception {

	public UpdateRoomTypeException() {
	}

	public UpdateRoomTypeException(String msg) {
		super(msg);
	}
}
