package util.exception;

public class DuplicateRoomException extends Exception {

	public DuplicateRoomException() {
	}

	public DuplicateRoomException(String msg) {
		super(msg);
	}
}
