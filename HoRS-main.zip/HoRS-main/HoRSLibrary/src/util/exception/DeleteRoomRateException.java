/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util.exception;

/**
 *
 * @author alast
 */
public class DeleteRoomRateException extends Exception {

    public DeleteRoomRateException() {
    }

    public DeleteRoomRateException(String msg) {
        super(msg);
    }

}
