package util.exception;

public class CreateNewOnlineReservationException extends Exception {

	public CreateNewOnlineReservationException() {
	}

	public CreateNewOnlineReservationException(String msg) {
		super(msg);
	}

}
