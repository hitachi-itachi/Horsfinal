package util.exception;

public class EntityInstanceExistsInCollectionException extends Exception {

    public EntityInstanceExistsInCollectionException() {
    }
    
    public EntityInstanceExistsInCollectionException(String msg) {
		super(msg);
	}
}
