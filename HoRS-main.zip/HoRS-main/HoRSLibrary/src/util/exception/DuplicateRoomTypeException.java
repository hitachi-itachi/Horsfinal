package util.exception;

public class DuplicateRoomTypeException extends Exception {

	public DuplicateRoomTypeException() {
	}

	public DuplicateRoomTypeException(String msg) {
		super(msg);
	}
}
