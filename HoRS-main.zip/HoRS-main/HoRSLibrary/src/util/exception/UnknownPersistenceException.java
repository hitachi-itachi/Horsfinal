package util.exception;

public class UnknownPersistenceException extends Exception {

	public UnknownPersistenceException() {
	}

	public UnknownPersistenceException(String msg) {
		super(msg);
	}
}
