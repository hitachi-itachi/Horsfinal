package util.exception;

public class EntityInstanceMissingInCollectionException extends Exception {

    public EntityInstanceMissingInCollectionException() {
    }
    
    public EntityInstanceMissingInCollectionException(String msg) {
		super(msg);
	}
}
