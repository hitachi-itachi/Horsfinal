package util.exception;

public class CreateNewPartnerReservationException extends Exception {

	public CreateNewPartnerReservationException() {
	}

	public CreateNewPartnerReservationException(String msg) {
		super(msg);
	}
}
