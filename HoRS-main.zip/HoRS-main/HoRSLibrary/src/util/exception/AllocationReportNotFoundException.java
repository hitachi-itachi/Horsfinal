package util.exception;

public class AllocationReportNotFoundException extends Exception {

	public AllocationReportNotFoundException() {
	}

	public AllocationReportNotFoundException(String msg) {
		super(msg);
	}

}
