package util.enumeration;

public enum StatusEnum {
	AVAILABLE, // In Use
	DISABLED // Not In Used, can be deleted
}
