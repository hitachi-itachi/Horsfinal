package util.enumeration;

public enum RateTypeEnum {
	PUBLISHED,
	NORMAL,
	PEAK,
	PROMOTION
}
