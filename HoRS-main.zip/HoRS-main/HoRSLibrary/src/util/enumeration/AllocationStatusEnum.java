package util.enumeration;

public enum AllocationStatusEnum {
	NOT_ALLOCATED,
	ALLOCATED,
	UPGRADED,
	NOT_UPGRADED
}
