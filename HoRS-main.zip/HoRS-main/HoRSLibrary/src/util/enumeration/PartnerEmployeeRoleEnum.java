package util.enumeration;

public enum PartnerEmployeeRoleEnum {
	PARTNERRESERVATIONMANAGER
}
