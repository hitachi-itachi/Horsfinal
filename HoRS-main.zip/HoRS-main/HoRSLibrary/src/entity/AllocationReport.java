package entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import util.enumeration.AllocationStatusEnum;
import util.enumeration.StatusEnum;

@Entity
public class AllocationReport implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long allocationReportId;
	private Integer roomNumber;
	private StatusEnum status;
	private Date checkInDate;
	private AllocationStatusEnum allocationStatus;

	@OneToMany
	@JoinColumn(name = "allocation_report_id")
	private List<ReservationDetail> reservationDetail;

	public AllocationReport() {
		reservationDetail = new ArrayList<>();
	}

	public AllocationReport(Integer roomNumber, StatusEnum status, Date checkInDate) {
		this.roomNumber = roomNumber;
		this.status = status;
		this.checkInDate = checkInDate;
	}

	public Long getAllocationReportId() {
		return allocationReportId;
	}

	public void setAllocationReportId(Long allocationReportId) {
		this.allocationReportId = allocationReportId;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (allocationReportId != null ? allocationReportId.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		// TODO: Warning - this method won't work in the case the allocationReportId fields are not set
		if (!(object instanceof AllocationReport)) {
			return false;
		}
		AllocationReport other = (AllocationReport) object;
		if ((this.allocationReportId == null && other.allocationReportId != null) || (this.allocationReportId != null && !this.allocationReportId.equals(other.allocationReportId))) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "entity.AllocationReport[ id=" + allocationReportId + " ]";
	}

	public Integer getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(Integer roomNumber) {
		this.roomNumber = roomNumber;
	}

	public StatusEnum getStatus() {
		return status;
	}

	public void setStatus(StatusEnum status) {
		this.status = status;
	}


	public Date getCheckInDate() {
		return checkInDate;
	}

	public void setCheckInDate(Date checkInDate) {
		this.checkInDate = checkInDate;
	}

	public List<ReservationDetail> getReservationDetail() {
		return reservationDetail;
	}

	public void setReservationDetail(List<ReservationDetail> reservationDetail) {
		this.reservationDetail = reservationDetail;
	}

	public AllocationStatusEnum getAllocationStatus() {
		return allocationStatus;
	}

	public void setAllocationStatus(AllocationStatusEnum allocationStatus) {
		this.allocationStatus = allocationStatus;
	}

}
