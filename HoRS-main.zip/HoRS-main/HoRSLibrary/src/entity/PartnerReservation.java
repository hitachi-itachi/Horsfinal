package entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class PartnerReservation extends Reservation implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@ManyToOne(optional=true)
	@JoinColumn(nullable=true)
	private PartnerEmployee partnerEmployee;

	public PartnerReservation() {
		super();
	}
	
	public PartnerReservation(PartnerEmployee partnerEmployee, BigDecimal ReservationFee, Date CheckInDate, Date CheckOutDate) {
		super(ReservationFee,  CheckInDate,  CheckOutDate);
		this.partnerEmployee = partnerEmployee;
	}

	public PartnerEmployee getPartnerEmployee() {
		return partnerEmployee;
	}

	public void setPartnerEmployee(PartnerEmployee partnerEmployee) {
		this.partnerEmployee = partnerEmployee;
	}
	
	@Override
	public int hashCode() {
		int hash = 0;
		hash += (reservationId != null ? reservationId.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		// TODO: Warning - this method won't work in the case the id fields are not set
		if (!(object instanceof PartnerReservation)) {
			return false;
		}
		PartnerReservation other = (PartnerReservation) object;
		if ((this.reservationId == null && other.reservationId != null) || (this.reservationId != null && !this.reservationId.equals(other.reservationId))) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "entity.PartnerReservation[ id=" + reservationId + " ]";
	}
	
}
