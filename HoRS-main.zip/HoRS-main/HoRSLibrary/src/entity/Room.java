package entity;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.xml.bind.annotation.XmlTransient;
import util.enumeration.StatusEnum;

@Entity
public class Room implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long roomId;
	private Integer roomNumber;
	private StatusEnum status;
	
	@ManyToOne(optional = false)
	@JoinColumn(nullable = false)
	private RoomType roomType;
       
	public Room() {}

	public Room(Integer roomNumber, StatusEnum status, RoomType roomType) {
		this.roomNumber = roomNumber;
		this.status = status;
		this.roomType = roomType;
	}

	public Long getRoomId() {
		return roomId;
	}

	public void setRoomId(Long roomId) {
		this.roomId = roomId;
	}

	public Integer getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(Integer roomNumber) {
		this.roomNumber = roomNumber;
	}

	public StatusEnum getStatus() {
		return status;
	}

	public void setStatus(StatusEnum status) {
		this.status = status;
	}

	public RoomType getRoomType() {
		return roomType;
	}

	public void setRoomType(RoomType roomType) {
//		if (this.roomType != null) {
//			this.roomType.getRooms().remove(this);
//		}

		this.roomType = roomType;
//
//		if (this.roomType != null) {
//			if (!this.roomType.getRooms().contains(this)) {
//				this.roomType.getRooms().add(this);
//			}
//		}
	}
	
	@Override
	public int hashCode() {
		int hash = 0;
		hash += (this.roomId != null ? this.roomId.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		// TODO: Warning - this method won't work in the case the roomNumber fields are not set
		if (!(object instanceof Room)) {
			return false;
		}
		Room other = (Room) object;
		if ((this.getRoomId() == null && other.getRoomId() != null) || (this.getRoomId() != null && !this.roomNumber.equals(other.roomNumber))) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "entity.Room[ id=" + getRoomId() + " ]";
	}

}
