package entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class ReservationDetail implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long reservationDetailId;
	private Integer numOfRooms;

	@ManyToOne(optional = false)
	@JoinColumn(nullable = false)
	private RoomType roomType;
	

	public ReservationDetail() {
	}

	public ReservationDetail(Integer numOfRooms, RoomType roomType) {
		this.numOfRooms = numOfRooms;
		this.roomType = roomType;
	}

	public Long getReservationDetailId() {
		return reservationDetailId;
	}

	public void setReservationDetailId(Long reservationDetailId) {
		this.reservationDetailId = reservationDetailId;
	}

	public Integer getNumOfRooms() {
		return numOfRooms;
	}

	public void setNumOfRooms(Integer numOfRooms) {
		this.numOfRooms = numOfRooms;
	}

	public RoomType getRoomType() {
		return roomType;
	}

	public void setRoomType(RoomType roomType) {
		this.roomType = roomType;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (reservationDetailId != null ? reservationDetailId.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		// TODO: Warning - this method won't work in the case the reservationDetailId fields are not set
		if (!(object instanceof ReservationDetail)) {
			return false;
		}
		ReservationDetail other = (ReservationDetail) object;
		if ((this.reservationDetailId == null && other.reservationDetailId != null) || (this.reservationDetailId != null && !this.reservationDetailId.equals(other.reservationDetailId))) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "entity.ReservationDetail[ id=" + reservationDetailId + " ]";
	}


}
