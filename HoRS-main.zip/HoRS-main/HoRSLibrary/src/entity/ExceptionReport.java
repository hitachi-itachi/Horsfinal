package entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ExceptionReport implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long reportId;
	private Date dateCreated;
	private String description;
	
	public ExceptionReport() {}
	
	public ExceptionReport(Date dateCreated, String description) {
		this.dateCreated = dateCreated;
		this.description = description;
	}

	public Long getReportId() {
		return reportId;
	}

	public void setReportId(Long reportId) {
		this.reportId = reportId;
	}

	public Date getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	@Override
	public int hashCode() {
		int hash = 0;
		hash += (reportId != null ? reportId.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		// TODO: Warning - this method won't work in the case the reportId fields are not set
		if (!(object instanceof ExceptionReport)) {
			return false;
		}
		ExceptionReport other = (ExceptionReport) object;
		if ((this.reportId == null && other.reportId != null) || (this.reportId != null && !this.reportId.equals(other.reportId))) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "entity.ExceptionReport[ id=" + reportId + " ]";
	}
	
}
