/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/SessionRemote.java to edit this template
 */
package ejb.session.stateless;

import entity.AllocationReport;
import entity.ReservationDetail;
import entity.Room;
import java.util.Date;
import java.util.List;
import javax.ejb.Remote;
import util.exception.AllocationReportNotFoundException;
import util.exception.CreateNewReportException;
import util.exception.RoomNotFoundException;

/**
 *
 * @author alast
 */
@Remote
public interface RoomAllocationSessionBeanRemote {

	public AllocationReport createNewAllocationRecord(ReservationDetail reservationDetail, AllocationReport allocationReport) throws CreateNewReportException;

	public List<ReservationDetail> retrieveReservationDetailByDate(Date checkedInDate) throws AllocationReportNotFoundException;

	public void updateReservationDetailsInAllocation(Date checkedInDate, ReservationDetail newReservationDetail) throws AllocationReportNotFoundException;

	public List<Integer> retrieveAListOfAllocatedRoomsNumber() throws RoomNotFoundException;

	public List<AllocationReport> retrieveAListOfUpgradedReservation() throws RoomNotFoundException;

	public List<AllocationReport> retrieveAListOfNotUpgradedReservation() throws RoomNotFoundException;
	// public void linkAllocationToReservation(ReservationDetail reservationDetail, AllocationReport allocationReport) throws CreateNewReportException;
	//  public List<AllocationReport> retrieveAllocationRecordByReservationId(Long reservationId);

	public List<AllocationReport> retrieveAllocationReportByReservationDetailId(Long reservationDetailId) throws AllocationReportNotFoundException;

	public void updateAllocationStatus(AllocationReport allocationReport);

}
