package ejb.session.stateless;

import entity.RoomType;
import java.math.BigDecimal;
import java.util.Date;
import javax.ejb.Remote;

@Remote
public interface OnlineReservationSessionBeanRemote {
	
	public BigDecimal calculateAmount(RoomType roomType, int numRoomsToReserve, Date checkInDate, Date checkOutDate);

}
