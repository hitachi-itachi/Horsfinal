package ejb.session.stateless;

import entity.OnlineReservation;
import entity.PartnerReservation;
import entity.Reservation;
import entity.ReservationDetail;
import entity.RoomType;
import entity.WalkInReservation;
import java.util.Date;
import java.util.List;
import javax.ejb.Remote;
import javax.persistence.NoResultException;
import util.exception.CreateNewOnlineReservationException;
import util.exception.CreateNewPartnerReservationException;
import util.exception.CreateNewWalkInReservationException;
import util.exception.EmployeeNotFoundException;
import util.exception.GuestNotFoundException;
import util.exception.PartnerNotFoundException;
import util.exception.ReservationDetailNotFoundException;
import util.exception.ReservationNotFoundException;

@Remote
public interface ReservationControllerSessionBeanRemote {

	public WalkInReservation createNewWalkInReservation(Long employeeId, WalkInReservation newWalkInReservation) throws EmployeeNotFoundException, CreateNewWalkInReservationException;

	public List<ReservationDetail> retrieveReservationDetailsByRoomTypeAndDate(RoomType roomType, Date checkInDate, Date checkOutDate);

	public List<ReservationDetail> retrieveReservationDetailsByDate(Date checkInDate);

	public ReservationDetail retrieveReservationDetailById(Long reservationDetailId) throws ReservationDetailNotFoundException;

	public OnlineReservation createNewOnlineReservation(Long guestId, OnlineReservation newOnlineReservation) throws GuestNotFoundException, CreateNewOnlineReservationException;

	public List<Reservation> retrieveOnlineReservationsByGuestId(Long guestId);

	public PartnerReservation createNewPartnerReservation(Long partnerId, PartnerReservation newPartnerReservation) throws PartnerNotFoundException, CreateNewPartnerReservationException;

	public Reservation retrieveReservationById(Long reservationId) throws ReservationNotFoundException;

	public List<Reservation> retrievePartnerReservationsByPartnerId(Long partnerId);

	public List<Reservation> retrieveReservationsByCheckInDate(Date checkinDate) throws NoResultException;
	
	public List<Reservation> retrieveReservationsByCheckOutDate(Date checkoutDate) throws NoResultException;

}
