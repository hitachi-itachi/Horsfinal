package ejb.session.stateless;

import entity.Room;
import entity.RoomRate;
import entity.RoomType;
import java.util.List;
import javax.ejb.Remote;
import util.exception.CreateNewRoomException;
import util.exception.CreateNewRoomRateException;
import util.exception.DeleteRoomException;
import util.exception.DeleteRoomRateException;
import util.exception.DeleteRoomTypeException;
import util.exception.DuplicateRoomException;
import util.exception.DuplicateRoomRateException;
import util.exception.DuplicateRoomTypeException;
import util.exception.RoomNotFoundException;
import util.exception.RoomRateNotFoundException;
import util.exception.RoomTypeNotFoundException;
import util.exception.UnknownPersistenceException;
import util.exception.UpdateRoomException;
import util.exception.UpdateRoomRateException;
import util.exception.UpdateRoomTypeException;

@Remote
public interface RoomManagementSessionBeanRemote {
	
	public long createNewRoomType(RoomType newRoomType) throws DuplicateRoomTypeException, UnknownPersistenceException;
	public List<RoomType> retrieveAllRoomTypes();
	public RoomType retrieveRoomType(Long roomTypeId) throws RoomTypeNotFoundException;
	public void updateRoomType(RoomType roomType) throws RoomTypeNotFoundException, UpdateRoomTypeException;
	public void deleteRoomType(Long roomTypeId) throws RoomTypeNotFoundException, DeleteRoomTypeException;
	
	public long createNewRoom(Long roomTypeId, Room newRoom) throws RoomTypeNotFoundException, CreateNewRoomException, DuplicateRoomException;
	public Room retrieveRoomById(Long roomId) throws RoomNotFoundException;
	public void updateRoom(Room room) throws RoomNotFoundException, UpdateRoomException;
	public List<Room> retrieveAllRooms();
	public void deleteRoom(int roomNumber) throws RoomNotFoundException, DeleteRoomException;
	
	public long createNewRoomRate(Long roomTypeId, RoomRate newRoomRate) throws RoomTypeNotFoundException, CreateNewRoomRateException, DuplicateRoomRateException;
	public List<RoomRate> retrieveAllRoomRates();
	public RoomRate retrieveRoomRate(Long roomRateId) throws RoomRateNotFoundException;
	public void updateRoomRate(RoomRate roomRate) throws RoomRateNotFoundException, UpdateRoomRateException;
	public void deleteRoomRate(Long roomRateId) throws RoomRateNotFoundException, DeleteRoomRateException;

	public RoomType retrieveRoomTypeByName(String name) throws RoomTypeNotFoundException;
	public  List<Room> retrieveRoomsByRank(Integer ranking) throws RoomTypeNotFoundException;
	
	public Room retrieveRoom(int roomNumber) throws RoomNotFoundException;


}
