package ejb.session.stateless;

import entity.Employee;
import java.util.List;
import javax.ejb.Remote;
import util.exception.EmployeeNotFoundException;
import util.exception.EmployeeUsernameExistException;
import util.exception.InputDataValidationException;
import util.exception.InvalidLoginCredentialException;
import util.exception.UnknownPersistenceException;

@Remote
public interface EmployeeSessionBeanRemote {
	
	public Long createNewEmployee(Employee newEmployee) throws EmployeeUsernameExistException, UnknownPersistenceException, InputDataValidationException;
	public Employee retrieveEmployeeByUsername(String username) throws EmployeeNotFoundException;
	public Employee retrieveEmployeeById(Long employeeId) throws EmployeeNotFoundException;
	public Employee employeeLogin(String username, String password) throws InvalidLoginCredentialException;
	public List<Employee> retrieveAllEmployees();

}
