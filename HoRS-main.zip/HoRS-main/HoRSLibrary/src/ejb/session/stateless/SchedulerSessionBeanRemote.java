/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/SessionRemote.java to edit this template
 */
package ejb.session.stateless;

import entity.ReservationDetail;
import java.util.Date;
import javax.ejb.Remote;

/**
 *
 * @author alast
 */
@Remote
public interface SchedulerSessionBeanRemote {
//	public void scheduleRoomAllocationAt2AM();

	public void automatedRoomAllocation();

	public void doRoomAllocationAuto();

	public void roomAllocation(Integer numOfRooms, Long roomTypeId, ReservationDetail reservationDetail, Date checkInDate);

	public void roomAllocationSameDay(Integer numOfRooms, Long roomTypeId, ReservationDetail reservationDetail, Date checkInDate);
}
